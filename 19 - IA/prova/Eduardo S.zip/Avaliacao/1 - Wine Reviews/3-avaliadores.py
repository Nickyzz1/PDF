import matplotlib.pyplot as plt
import pandas as pd
from statistics import mean

df = pd.read_csv('./winemag-data-130k-v2.csv')

avaliadores = []

avaliadores = list(df['taster_name'].dropna().unique())

notas = []

for avaliador in avaliadores:
    filter = ( df.taster_name == avaliador)
    notas.append(mean(df[filter].points))

plt.plot(avaliadores, notas)

plt.xlabel("Avaliadores")
plt.ylabel("Média de Notas")

plt.show()
