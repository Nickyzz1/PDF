import matplotlib.pyplot as plt
import pandas as pd
from statistics import mean

df = pd.read_csv('./winemag-data-130k-v2.csv')

precos = df.groupby('price')['id'].nunique()

quality = df.groupby('price')['points'].nunique()

plt.scatter(list(precos), list(quality))

plt.show()