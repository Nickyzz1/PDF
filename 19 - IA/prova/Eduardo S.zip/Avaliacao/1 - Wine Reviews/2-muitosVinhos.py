import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('./winemag-data-130k-v2.csv')


for row in df['title'].values:
    row += str(row).split('(')

print(df['title'])

# plt.plot(df['winery'])
# plt.plot(df[''])