import pandas as pd

df = pd.read_csv('./winemag-data-130k-v2.csv')

vinhos = len(list(df['title'].unique()))

print(f'Aproximadamente: {vinhos} vinhos')