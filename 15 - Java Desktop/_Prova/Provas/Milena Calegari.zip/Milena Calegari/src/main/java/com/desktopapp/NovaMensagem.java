package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.MensagemData;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class NovaMensagem {
   public static Scene CreateScene() throws Exception{
        URL sceneUrl = Cadastro.class.getResource("NovaMensagem.fxml");
        FXMLLoader loader  = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        return scene;
    }

    @FXML
    protected TextField destino;

    @FXML
    protected TextField mensagem;


    @FXML
    protected Button btnEnviar;

    @FXML
    public void enviarMsg(MouseEvent e) throws Exception{
        MensagemData envio = new MensagemData();
        envio.setDestinatario(destino.getText());
        envio.setMensagem(mensagem.getText());
        envio.setRemetente(MainController.class.getName());
    }
}
