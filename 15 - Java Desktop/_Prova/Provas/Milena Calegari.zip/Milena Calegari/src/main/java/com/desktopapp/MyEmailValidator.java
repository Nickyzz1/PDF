package com.desktopapp;

public class MyEmailValidator {
    public static boolean ValidadeEmail(String email) {
        
        if(email.contains("@")){
            email.split("@");
            return true;
        }
        
        return email.chars().anyMatch(c -> c >= '0' && c <= '9');
    }
}
