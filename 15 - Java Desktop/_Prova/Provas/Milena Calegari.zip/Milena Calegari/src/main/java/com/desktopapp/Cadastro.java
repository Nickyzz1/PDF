package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.UserData;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import com.desktopapp.MyEmailValidator;

public class Cadastro{
    public static Scene CreateScene() throws Exception{
        URL sceneUrl = Cadastro.class.getResource("Cadastro.fxml");
        FXMLLoader loader  = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        return scene;
    }

    @FXML
    protected Button btnCadastrar;

    @FXML
    protected TextField nomeCadastro;

    @FXML
    protected TextField emailCadastro;

    @FXML
    protected PasswordField senhaCadastro;

    @FXML
    protected PasswordField repSenhaCadastro;
    
    @FXML
    public void cadastrar(MouseEvent e) throws Exception{
        Context ctx = new Context();

        if(!repSenhaCadastro.getText().equals(senhaCadastro.getText())){
            Alert alert = new Alert(
                AlertType.ERROR,
                "As senhas são diferentes!",
                ButtonType.OK);
                alert.showAndWait();
                return;
        } 
        var nameUser = ctx.find(UserData.class,
                "SELECT u FROM UserData u WHERE u.name = :arg0",
                nomeCadastro.getText()
        );
                
        var emailUser = ctx.find(UserData.class,
            "SELECT u FROM UserData u WHERE u.email = :arg0",
            emailCadastro.getText()
        );

        if (nameUser.size() != 0 || emailUser.size() != 0) {
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "Nome ou Email de usuário já cadastrado!",
                    ButtonType.OK);
            alert.showAndWait();
            return;
        }

        else{
            UserData user = new UserData();
            user.setName(nomeCadastro.getText());

            if(MyEmailValidator.ValidadeEmail(emailCadastro.getText()) ==  false){
                Alert alert = new Alert(
                    AlertType.ERROR,
                    "O campo de email deve possuir @",
                    ButtonType.OK
                );
                alert.showAndWait();
                return;
            }
            
            if(MyPasswordValidator.ValidateSenha(senhaCadastro.getText()) == false){
                Alert alert = new Alert(
                    AlertType.ERROR,
                    "A senha deve ser maior!",
                    ButtonType.OK
                );
                alert.showAndWait();
                return;
            }
                
            user.setEmail(emailCadastro.getText());
            user.setPassword(senhaCadastro.getText()); 
    
            ctx.begin();
            ctx.save(user);
            ctx.commit();
        }

        var crrStage = (Stage) btnCadastrar.getScene().getWindow();
        crrStage.close();
        
        var stage = new Stage();
        var scene = MainController.CreateScene();
        stage.setScene(scene);
        stage.show();
        
    }
}
