package com.desktopapp;

import java.net.URL;

import org.hibernate.mapping.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import com.desktopapp.model.LogadoData;
import com.desktopapp.model.UserData;

public class MainController{
    public static Scene CreateScene() throws Exception {
        URL sceneUrl = MainController.class.getResource("MainController.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        return scene;
    }

    @FXML
    protected Button btLogar;

    @FXML
    protected CheckBox verSenha;

    @FXML
    protected TextField login;

    @FXML
    protected PasswordField senha;

    @FXML 
    protected Button btnCadastro;

    @FXML
    protected void logarUsuario(MouseEvent e) throws Exception {
        Context ctx = new Context();

        var user = ctx.find(UserData.class,
            "SELECT u FROM UserData u WHERE u.email = :arg0 OR u.name =:arg0",
            login.getText()
        );


        if (user.size() == 0 ) {
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "Nome ou Email não cadastrado!",
                    ButtonType.OK
            );
            alert.showAndWait();
            return;
        }

        var users = user.get(0);


        if( (!senha.getText().equals(users.getPassword()))){
            Alert alert = new Alert(
                AlertType.ERROR,
                "Senha incorreta!",
                ButtonType.OK);
            alert.showAndWait();
            return;
        }

        LogadoData usuarioLogado = new LogadoData();
        usuarioLogado.setNomeLogado(login.getText());

        var crrStage = (Stage) btLogar.getScene().getWindow();
        crrStage.close();
        
        var stage = new Stage();
        var scene = MainSceneController.CreateScene();
        stage.setScene(scene);
        stage.show();
        
    }

    @FXML void cadastrarUser(MouseEvent e) throws Exception{
        var crrStage = (Stage) btnCadastro.getScene().getWindow();
        crrStage.close();
        
        var stage = new Stage();
        var scene = Cadastro.CreateScene();
        stage.setScene(scene);
        stage.show();
    }

}
