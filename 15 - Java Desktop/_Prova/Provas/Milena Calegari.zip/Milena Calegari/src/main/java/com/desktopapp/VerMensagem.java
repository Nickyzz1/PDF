package com.desktopapp;

import java.net.URL;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.fxml.Initializable;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.List;

import com.desktopapp.model.MensagemData;

public class VerMensagem implements Initializable{
    public static Scene CreateScene() throws Exception {
        URL sceneUrl = VerMensagem.class.getResource("VerMensagem.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        return scene;
    }

    @FXML
    protected TableView caixaEntrada;

    @FXML
    protected TableColumn id;

    @FXML
    protected TableColumn  remetente;

    @FXML
    protected TableColumn  mensagem;


    @Override
    public void initialize(URL location, ResourceBundle resources){
        Context consulta  = new Context();
        var retornoTipo = consulta.createQuery(MensagemData.class, "SELECT msg FROM MensagemData msg").setMaxResults(20).getResultList();

        var rem =  ctx.find(MensagemData.class,
            "SELECT m.remetente FROM MensagemData m WHERE m.destino = :arg0",
            
        );

        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        

        var itemsTabela = FXCollections.observableArrayList(retornoTipo);

        caixaEntrada.setItems(listaMensagens());
    }

    protected ObservableList<MensagemData> listaMensagens(){
        Context ctx = new Context();
        ctx.begin();

        List<MensagemData> lista = ctx.findAll(MensagemData.class);

        return FXCollections.observableArrayList(
            lista
        );
    }
}   