package com.desktopapp;

import java.io.IOException;
import java.lang.classfile.Label;
import java.net.URL;
import java.util.ResourceBundle;

import com.desktopapp.model.LogadoData;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
 
public class MainSceneController implements Initializable{
    public static Scene CreateScene() throws Exception
    {
        URL sceneUrl = MainSceneController.class.getResource("main-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }

    @FXML
    protected AnchorPane menu;

    @FXML
    protected AnchorPane tela;

    @FXML 
    protected Button novaMsg;

    @FXML
    protected Button sair;

    @FXML 
    protected Label<LogadoData, String> nomeUser;


    @FXML
    public void novaMensagem(MouseEvent e) throws  Exception{
        VBox item =  FXMLLoader.load(NovaMensagem.class.getResource("NovaMensagem.fxml"));
        tela.setTopAnchor(item, 0.0);
        tela.setBottomAnchor(item, 0.0);
        tela.setLeftAnchor(item, 0.0);
        tela.setRightAnchor(item, 0.0);

        tela.getChildren().setAll(item);

    }

    @FXML
    public void logout(MouseEvent e) throws Exception{
        var crrStage = (Stage) sair.getScene().getWindow();
        crrStage.close();
        
        var stage = new Stage();
        var scene = MainController.CreateScene();
        stage.setScene(scene);
        stage.show();
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        VBox item =  FXMLLoader.load(VerMensagem.class.getResource("VerMensagem.fxml"));
        tela.setTopAnchor(item, 0.0);
        tela.setBottomAnchor(item, 0.0);
        tela.setLeftAnchor(item, 0.0);
        tela.setRightAnchor(item, 0.0);

        tela.getChildren().setAll(item);
    }

    
}