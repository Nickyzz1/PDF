package com.desktopapp;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class ValidatorTests {

    
    @Test
    void validateGeralPasswords() {

        ArrayList<String> emptyList = new ArrayList<>();
        assertEquals(Validator.ValidatePass("senhadaora*123"), emptyList);

        ArrayList<String> error = new ArrayList<>();
        error.add("The password must have at least 8 characters");
        
        assertEquals(Validator.ValidatePass("a@123"), error);
        
        error.add("Your password must contain numbers");
        assertEquals(Validator.ValidatePass("a&"), error);
        
        error.add("Your password must contain special characters");
        assertEquals(Validator.ValidatePass("a"), error);
    }

    @Test
    void validateSpecialPasswords() {

        ArrayList<String> error = new ArrayList<>();
        error.add("Your password must contain special characters");
        
        assertEquals(Validator.ValidatePass("senhasemespecial123"), error);
    }

    @Test
    void validateSmallPasswords() {

        ArrayList<String> error = new ArrayList<>();
        error.add("The password must have at least 8 characters");
        
        assertEquals(Validator.ValidatePass("curto1$"), error);
    }

    @Test
    void validateNoNumberPasswords() {

        ArrayList<String> error = new ArrayList<>();
        error.add("Your password must contain numbers");
        
        assertEquals(Validator.ValidatePass("senhasemnumero!@$"), error);
    }

    @Test
    void validateMails() {
        assertEquals(Validator.ValidateEmail("minhasenha"), false);
        assertEquals(Validator.ValidateEmail("jose@mail"), false);
        assertEquals(Validator.ValidateEmail("jose@mail.com"), true);
        assertEquals(Validator.ValidateEmail("jose@mail."), false);
        assertEquals(Validator.ValidateEmail("jose.mail@com"), false);
        assertEquals(Validator.ValidateEmail("jose.mail.@com"), false);
        assertEquals(Validator.ValidateEmail("jose@.com"), false);
        assertEquals(Validator.ValidateEmail("jose@a.a"), true);
        assertEquals(Validator.ValidateEmail("@a.a"), false);
        assertEquals(Validator.ValidateEmail("a@a.a"), true);
    }
}