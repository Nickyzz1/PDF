package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Mail;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;

public class ViewMailSceneController {
    
    public static Scene CreateScene(Mail mail) throws Exception {

        URL sceneUrl = ViewMailSceneController.class
            .getResource("view-mail-scene.fxml");

        FXMLLoader loader = new FXMLLoader(sceneUrl);
        
        Parent root = loader.load();

        ViewMailSceneController controller = loader.getController();

        controller.LoadMail(mail);

        Scene scene = new Scene(root);
        
        return scene;
    }
    
    @FXML
    TextField tfSubject;
    
    @FXML
    TextField tfSender;
    
    @FXML
    TextField tfReceiver;
    
    @FXML
    TextField tfText;
    
    private void LoadMail(Mail mail) {
        
        tfSubject.setText(mail.getSubject());
        tfSender.setText(mail.getSender());
        tfReceiver.setText(mail.getReceiver());
        tfText.setText(mail.getText());
    }

}
