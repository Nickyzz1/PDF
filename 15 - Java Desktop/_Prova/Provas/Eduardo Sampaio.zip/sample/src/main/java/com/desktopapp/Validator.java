package com.desktopapp;

import java.util.ArrayList;

public class Validator {
    
    public static ArrayList<String> ValidatePass(String password) {

        ArrayList<String> errors = new ArrayList<>();

        if (password.length() < 8)
            errors.add("The password must have at least 8 characters");
            
        if(!password.chars().anyMatch(c -> c >= '0' && c <= '9'))
            errors.add("Your password must contain numbers");
            
        if (!password.chars().anyMatch(c -> c >= '!' && c <= '/' || c >= ':' && c <= '@'))
            errors.add("Your password must contain special characters");

        if (!password.chars().anyMatch(c -> c >= 'a' && c <= 'z'))
            errors.add("Your password must contain letters");

        return errors;
    }

    public static boolean ValidateEmail(String email){

        try{
            if(email.indexOf('@') < 1)
            return false;
            
            if(!(email.indexOf('@') < email.indexOf('.') - 1))
                return false;
            
            if(!(email.indexOf('.') < email.length() - 1))
                return false;
            
            return true;
        }
        catch(Exception e){
            return false;
        }
    }
}
