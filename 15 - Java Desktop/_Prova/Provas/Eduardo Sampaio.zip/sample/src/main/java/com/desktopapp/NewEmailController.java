package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.Mail;
import com.desktopapp.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class NewEmailController {

    private static Long userId;
    
    public static Scene CreateScene(Long id) throws Exception
    {
        URL sceneUrl = NewEmailController.class
            .getResource("new-mail-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);

        userId = id;

        return scene;
    }

    @FXML
    TextField tfSubject;

    @FXML
    TextField tfReceiver;

    @FXML
    TextField tfText;

    @FXML
    Button btSend;

    @FXML
    private void SendMail(ActionEvent e) throws Exception {

        Context ctx = new Context();

        var query = ctx.createQuery(User.class,
        "SELECT u FROM User u WHERE u.id = :arg0");
        query.setParameter("arg0", userId);
        
        List<User> users = query.getResultList();

        var user = users.get(0);

        Mail mail = new Mail();

        mail.setSender(user.getEmail());
        mail.setSubject(tfSubject.getText());
        mail.setReceiver(tfReceiver.getText());
        mail.setText(tfText.getText());

        ctx.begin();
        ctx.persist(mail);
        ctx.commit();

        Stage crrStage = (Stage) btSend.getScene().getWindow();

        crrStage.close();
    }


}
