package com.desktopapp;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import com.desktopapp.model.Mail;
import com.desktopapp.model.User;

import jakarta.persistence.TypedQuery;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

public class MailsSceneController implements Initializable{

    private static Long userId;
    
    public static VBox CreateScene(Long id) throws Exception
    {
        URL sceneUrl = MailsSceneController.class
            .getResource("mails-scene.fxml");

        FXMLLoader loader = new FXMLLoader(sceneUrl);
        
        VBox scene = loader.load();

        MailsSceneController controller = loader.getController();
        
        controller.LoadMails(id);
        controller.AddColumns();

        userId = id;
        
        return scene;
    }
    
    Timer timer = new Timer();
    
    @FXML
    protected Button btNewMail;
    
    @FXML
    protected TableView<Mail> tbMails;
    
    @FXML
    TableColumn<Mail, String> subjectCol;
    
    @FXML
    TableColumn<Mail, Float> senderCol;
    
    @FXML
    private void NewMail(ActionEvent e){
        
        try {
            
            Scene scene = NewEmailController.CreateScene(userId);
            
            Stage newStage = new Stage();
            
            newStage.setScene(scene);
            
            newStage.showAndWait();
            
            LoadMails(userId);
            
        } catch (Exception ex) {
            System.out.print(ex.getMessage());
        }
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                LoadMails(userId);
            }
        }, 50, 5000);
    }
    
    private void LoadMails(Long userId) {
        
        Context ctx = new Context();

        var userQuery = ctx.createQuery(User.class,
        "SELECT u FROM User u WHERE u.id = :arg0");
        userQuery.setParameter("arg0", userId);

        User user = userQuery.getResultList().get(0);

        TypedQuery<Mail> mailQuery = ctx.createQuery(Mail.class, "SELECT m FROM Mail m where m.receiver = :arg0");
        mailQuery.setParameter("arg0", user.getEmail());

        List<Mail> mails = mailQuery.getResultList();

        subjectCol.setCellValueFactory(
            new PropertyValueFactory<>("subject")
        );

        senderCol.setCellValueFactory(
            new PropertyValueFactory<>("sender")
        );

        tbMails.setItems(FXCollections.observableArrayList(mails));

    }

    private void AddColumns() {

        TableColumn<Mail, Void> viewCol = new TableColumn<>("View");

        viewCol.setPrefWidth(50);

        Callback<TableColumn<Mail, Void>, TableCell<Mail, Void>> viewCellFactory = (final TableColumn<Mail, Void> param) -> {
            final TableCell<Mail, Void> cell = new TableCell<Mail, Void>() {
                
                private final Button btn = new Button("View");
                {
                    btn.setOnAction((ActionEvent event) -> {

                        Mail mail = getTableView().getItems().get(getIndex());

                        try {
                            var stage = new Stage();
                            var scene = ViewMailSceneController.CreateScene(mail);
                            stage.setScene(scene);
                            stage.showAndWait();
                            LoadMails(userId);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    });
                }
                
                @Override
                public void updateItem(Void item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        setGraphic(btn);
                    }
                }
            };
            return cell;
        };

        viewCol.setCellFactory(viewCellFactory);

        tbMails.getColumns().add(viewCol);
    }


}
