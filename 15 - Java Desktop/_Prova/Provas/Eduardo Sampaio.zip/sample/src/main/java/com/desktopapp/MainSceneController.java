package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
 
public class MainSceneController {

    private static Long userId;
     
    public static Scene CreateScene(Long id) throws Exception
    {
        URL sceneUrl = MainSceneController.class
        .getResource("main-scene.fxml");

        FXMLLoader loader = new FXMLLoader(sceneUrl);
        
        Parent root = loader.load();

        MainSceneController controller = loader.getController();
        
        Context ctx = new Context();
        var query = ctx.createQuery(User.class,
        "SELECT u FROM User u WHERE u.id = :arg0");
        query.setParameter("arg0", id);
        
        List<User> users = query.getResultList();
        
        controller.HelloUser(users.get(0).getName());

        userId = id;

        Scene scene = new Scene(root);

        return scene;
    }

    @FXML
    protected AnchorPane apMain;

    @FXML
    protected Label lbHello;

    @FXML
    protected Button btLogout;

    @FXML
    private void ShowMails(ActionEvent e) throws Exception {

        VBox mails = MailsSceneController.CreateScene(userId);

        apMain.getChildren().setAll(mails);
    }

    @FXML
    private void Logout(ActionEvent e) throws Exception {

        var crrStage = (Stage)btLogout
            .getScene().getWindow();
 
        var scene = LoginSceneController.CreateScene();
        crrStage.setScene(scene);
    }

    private void HelloUser(String name){

        lbHello.setText("Olá, " + name);
    }
}