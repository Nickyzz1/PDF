package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
 
public class CreateAccountSceneController {
     
    public static Scene CreateScene() throws Exception
    {
        URL sceneUrl = CreateAccountSceneController.class
            .getResource("create-account-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }

    @FXML
    protected Button btCreate;
 
    @FXML
    protected TextField tfName;

    @FXML
    protected TextField tfEmail;
 
    @FXML
    protected PasswordField pfPass;

    @FXML
    protected PasswordField pfPass1;

    @FXML
    protected void createAccount(ActionEvent e) throws Exception {

        // Usuário ou e-mail não inseridos
        if(tfName.getText().isBlank() || tfEmail.getText().isBlank())
            return;

        // Senha e repetir senha iguais
        if(!pfPass.getText().equals(pfPass1.getText()))
            return;
            
        User newUser = new User();

        newUser.setName(tfName.getText());
        newUser.setEmail(tfEmail.getText());
        newUser.setPassword(pfPass.getText());

        // Validando os E-mails
        if(!Validator.ValidateEmail(newUser.getEmail())){
            Alert alert = new Alert(
                AlertType.ERROR,
                "E-mail must have E-mail format",
                ButtonType.OK
            );
            alert.showAndWait();
            return;
        }

        // Validando senhas
        var validPass = Validator.ValidatePass(newUser.getPassword());

        if(!validPass.isEmpty()){

            String message = new String();

            for (String error : validPass) {

                error = error.concat("\n");
                message = message.concat(error);
            }

            Alert alert = new Alert(
                AlertType.ERROR,
                message,
                ButtonType.OK
            );
            alert.showAndWait();
            return;
        }

        // Validando usuários existentes 

        Context ctx = new Context();

        var query = ctx.createQuery(User.class,
            "SELECT u FROM User u WHERE u.name = :arg0 or u.email = :arg1");
            query.setParameter("arg0", newUser.getName());
            query.setParameter("arg1", newUser.getEmail());
        List<User> users = query.getResultList();

        if(!users.isEmpty())
        {
            var user = users.get(0);

            if(user.getEmail().equals(newUser.getEmail()))
            {
                Alert alert = new Alert(
                    AlertType.ERROR,
                    "This E-mail belongs to an existing user",
                    ButtonType.OK
                );
                alert.showAndWait();
            }

            if(user.getName().equals(newUser.getName()))
            {
                Alert alert = new Alert(
                    AlertType.ERROR,
                    "This Username already in use, please choose another",
                    ButtonType.OK
                );
                alert.showAndWait();
            }
            return;
        }

        // Adicionando Usuário

        ctx.begin();
        ctx.persist(newUser);
        ctx.commit();

        Stage currStage = (Stage)btCreate.getScene().getWindow();

        currStage.close();
    }
}