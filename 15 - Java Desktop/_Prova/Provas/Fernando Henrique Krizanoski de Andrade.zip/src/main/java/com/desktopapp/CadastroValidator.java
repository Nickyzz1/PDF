package com.desktopapp;

import java.util.ArrayList;
import java.util.List;

import com.desktopapp.model.User;

public class CadastroValidator {
    public static ArrayList<String> Validate(String nome, String email, String senha, String repetirSenha) {
        ArrayList<String> erros = new ArrayList<>();

        ValidateNome(nome).forEach(a -> erros.add(a));

        ValidateEmail(email).forEach(a -> erros.add(a));

        ValidateSenha(senha).forEach(a -> erros.add(a));

        if(!senha.equals(repetirSenha))
            erros.add("A senha repetida não é igual a primeira");

        return erros;
    }

    public static ArrayList<String> ValidateNome(String nome) {
        ArrayList<String> erros = new ArrayList<>();

        Context ctx = new Context();

        List<User> nomes = ctx.createQuery(User.class,
            "SELECT u FROM User u WHERE u.nome = '" + nome + "'").getResultList();

        if(!nomes.isEmpty())
            erros.add("O nome inserido já está em uso");
        
        if(nome.isEmpty())
            erros.add("Nenhum nome inserido");

        return erros;
    }

    public static ArrayList<String> ValidateEmail(String email) {
        ArrayList<String> erros = new ArrayList<>();

        Context ctx = new Context();

        List<User> emails = ctx.createQuery(User.class,
            "SELECT u FROM User u WHERE u.email = '" + email + "'").getResultList();
        
        if(!emails.isEmpty())
            erros.add("O email inserido já está em uso");

        if(!(email.contains("@") && email.contains(".") && !email.endsWith(".") && !email.startsWith("@") && !email.contains("@."))) {
            erros.add("O email inserido não está na formatação correta");
        }
        
        return erros;
    }

    public static ArrayList<String> ValidateSenha(String senha) {
        ArrayList<String> erros = new ArrayList<>();

        if(!senha.chars().anyMatch(c -> c >= '0' && c <= '9'))
            erros.add("A senha inserida não tem numeros");

        if(senha.length() < 8)
            erros.add("A senha inserida tem menos que 8 caracteres");
        
        if(!senha.toLowerCase().chars().anyMatch(c -> c >= 'a' && c <= 'z'))
            erros.add("A senha inserida não tem letras");

        if(!senha.toLowerCase().chars().anyMatch(c -> !(c >= '0' && c <= '9') && !(c >= 'a' && c <= 'z')))
            erros.add("A senha inserida não tem caracteres especiais");

        return erros;
    }
}
