package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Mensagem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MensagemController {

    String remetente;
    public void setRemetente(String remetente) {
        this.remetente = remetente;
    }

    public static Scene CreateScene(String emailRemetente) throws Exception
    {
        URL sceneUrl = MainSceneController.class
            .getResource("enviarMensagem-scene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        MensagemController controller = loader.getController();
        controller.setRemetente(emailRemetente);
        return scene;
    }

    @FXML
    protected Button btVoltar;

    @FXML
    protected Button btEnviar;

    @FXML
    protected TextField inputEmail;

    @FXML
    protected TextField inputTitulo;

    @FXML
    protected TextArea inputTexto;

    @FXML
    protected void enviar() throws Exception {
        Context ctx = new Context();
        Mensagem mensagem = new Mensagem();
        mensagem.setRemetente(remetente);
        mensagem.setDestinatario(inputEmail.getText());
        mensagem.setTitulo(inputTitulo.getText());
        mensagem.setTexto(inputTexto.getText());

        ctx.begin();
        ctx.persist(mensagem);
        ctx.commit();

        voltar();
    }

    @FXML
    protected void voltar() throws Exception {
        Stage oldStage = (Stage)btVoltar.getScene().getWindow();
        oldStage.close();
    }
}
