package com.desktopapp;

import java.net.URL;
import java.util.ArrayList;

import com.desktopapp.model.User;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CadastroController {
    public static Scene CreateScene() throws Exception {
        URL sceneUrl = CadastroController.class.getResource("cadastro-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);

        return scene;
    }

    @FXML
    protected Button btVoltar;

    @FXML
    protected Button btCadastrar;
 
    @FXML
    protected TextField inputNome;

    @FXML
    protected TextField inputEmail;
 
    @FXML
    protected PasswordField inputSenha;

    @FXML
    protected PasswordField inputRepetirSenha;
    
    @FXML
    protected void cadastrar() throws Exception {

        ArrayList<String> erros = CadastroValidator.Validate(inputNome.getText(), inputEmail.getText(), inputSenha.getText(), inputRepetirSenha.getText());
        if (!erros.isEmpty()) {
            Alert alert = new Alert(
                AlertType.ERROR,
                erros.toString(),
                ButtonType.OK
            );
            alert.showAndWait();
            return;
        }

        Context ctx = new Context();
        
        User user = new User();
        user.setNome(inputNome.getText());
        user.setEmail(inputEmail.getText());
        user.setSenha(inputSenha.getText());

        ctx.begin();
        ctx.persist(user);
        ctx.commit();

        voltar();
    }

    @FXML
    protected void voltar() throws Exception {
        Stage oldStage = (Stage)btVoltar.getScene().getWindow();
        oldStage.close();

        Stage newStage = new Stage();
        Scene newScene = LoginSceneController.CreateScene();

        newStage.setScene(newScene);
        newStage.show();
    }
}
