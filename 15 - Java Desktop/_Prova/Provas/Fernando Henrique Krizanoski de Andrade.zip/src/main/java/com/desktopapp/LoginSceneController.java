package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginSceneController {

    public static Scene CreateScene() throws Exception {
        URL sceneUrl = LoginSceneController.class
                .getResource("login-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }
    
    @FXML
    protected Button btLogin;

    @FXML
    protected Button btCadastrar;
 
    @FXML
    protected TextField inputLogin;
 
    @FXML
    protected PasswordField inputSenha;
 
    @FXML
    protected void cadastrar() throws Exception {
        Stage oldStage = (Stage)btCadastrar.getScene().getWindow();
        oldStage.close();

        Stage newStage = new Stage();
        Scene newScene = CadastroController.CreateScene();

        newStage.setScene(newScene);
        newStage.show();
    }

    @FXML
    protected void login(ActionEvent e) throws Exception {

        Context ctx = new Context();
        var query = ctx.createQuery(User.class,
            "SELECT u FROM User u WHERE u.nome = '" + inputLogin.getText() + "' or u.email = '" + inputLogin.getText() + "'");
        List<User> users = query.getResultList();

        if (users.isEmpty()) {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Usuário não encontrado!",
                ButtonType.OK
            );
            alert.showAndWait();
            return;
        }

        User user = users.get(0);
 
        if (!inputSenha.getText().equals(user.getSenha())) {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Senha incorreta!",
                ButtonType.OK
            );
            alert.showAndWait();
            return;
        }
 
        var stageAtual = (Stage)btLogin.getScene().getWindow();
 
        var scene = MainSceneController.CreateScene(user);
        stageAtual.setScene(scene);
        stageAtual.show();
    }

}
