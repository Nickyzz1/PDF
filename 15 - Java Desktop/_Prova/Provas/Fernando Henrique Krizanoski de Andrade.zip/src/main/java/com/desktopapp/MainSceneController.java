package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.Mensagem;
import com.desktopapp.model.User;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
 
public class MainSceneController {

    User user;
     
    public void setUser(User user) {
        this.user = user;
    }

    public static Scene CreateScene(User user) throws Exception
    {
        URL sceneUrl = MainSceneController.class
            .getResource("main-scene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        MainSceneController controller = loader.getController();
        controller.setUser(user);
        controller.textOla.setText("Ola, " + user.getNome());
        controller.listar();
        return scene;
    }


    @FXML
    protected Button btLogout;

    @FXML
    protected Button btEnviarMensagem;

    @FXML
    protected Label textOla;

    @FXML
    protected ListView<String> lista;

    @FXML
    protected void enviarMensagem() throws Exception {
        Stage newStage = new Stage();
        Scene newScene = MensagemController.CreateScene(user.getEmail());

        newStage.setScene(newScene);
        newStage.show();
    }

    @FXML
    protected void logout() throws Exception {
        Stage stage = (Stage)btLogout.getScene().getWindow();
        Scene newScene = LoginSceneController.CreateScene();

        stage.setScene(newScene);
        stage.show();
    }
    ObservableList<String> names = FXCollections.observableArrayList();

    public void listar() {
        Context ctx = new Context();

        List<Mensagem> emails = ctx.createQuery(Mensagem.class,
        "SELECT m FROM Mensagem m WHERE m.destinatario = '" + user.getEmail() + "'").getResultList();

        for (int i = 0; i < emails.size(); i++) {
            names.add(i, "Titulo: " + emails.get(i).getTitulo() + "\nRemetente: " + emails.get(i).getRemetente());
        }

        lista.setItems(names);
        // lista.addEventHandler("onClick", get);
    }

    // public void abrirMensagem(){

    // }
}