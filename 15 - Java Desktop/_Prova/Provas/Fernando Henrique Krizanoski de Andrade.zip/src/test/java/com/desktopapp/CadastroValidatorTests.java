package com.desktopapp;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class CadastroValidatorTests {

    @Test
    void validateNomeVazio() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("Nenhum nome inserido");
        assertEquals(CadastroValidator.ValidateNome(""), erro);
    }

    @Test
    void validateEmailTerminandoComPonto() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("O email inserido não está na formatação correta");
        assertEquals(CadastroValidator.ValidateEmail("nome@email."), erro);
    }

    @Test
    void validateEmailComeçandoComArroba() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("O email inserido não está na formatação correta");
        assertEquals(CadastroValidator.ValidateEmail("@email.com"), erro);
    }

    @Test
    void validateEmailArrobaEPontoJuntos() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("O email inserido não está na formatação correta");
        assertEquals(CadastroValidator.ValidateEmail("nome@.com"), erro);
    }

    @Test
    void validateSenhaPequenaComLetraNumeroECaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida tem menos que 8 caracteres");
        assertEquals(CadastroValidator.ValidateSenha("senha1@"), erro);
    }

    @Test
    void validateSenhaPequenaComLetraNumeroESemCaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida tem menos que 8 caracteres");
        erro.add("A senha inserida não tem caracteres especiais");
        assertEquals(CadastroValidator.ValidateSenha("senha12"), erro);
    }

    @Test
    void validateSenhaPequenaSemNumeroEComLetraECaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida não tem numeros");
        erro.add("A senha inserida tem menos que 8 caracteres");
        assertEquals(CadastroValidator.ValidateSenha("senha!@"), erro);
    }

    @Test
    void validateSenhaPequenaComLetraSemNumeroECaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida não tem numeros");
        erro.add("A senha inserida tem menos que 8 caracteres");
        erro.add("A senha inserida não tem caracteres especiais");
        assertEquals(CadastroValidator.ValidateSenha("senha"), erro);
    }

    @Test
    void validateSenhaPequenaComnumeroECaracterEspecialSemLetra() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida tem menos que 8 caracteres");
        erro.add("A senha inserida não tem letras");
        assertEquals(CadastroValidator.ValidateSenha("123!@#"), erro);
    }

    @Test
    void validateSenhaPequenaComnumeroSemLetraECaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida tem menos que 8 caracteres");
        erro.add("A senha inserida não tem letras");
        erro.add("A senha inserida não tem caracteres especiais");
        assertEquals(CadastroValidator.ValidateSenha("123456"), erro);
    }

    @Test
    void validateSenhaVazia() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida não tem numeros");
        erro.add("A senha inserida tem menos que 8 caracteres");
        erro.add("A senha inserida não tem letras");
        erro.add("A senha inserida não tem caracteres especiais");
        assertEquals(CadastroValidator.ValidateSenha(""), erro);
    }

    @Test
    void validateSenhaGrandeComLetraNumeroECaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        assertEquals(CadastroValidator.ValidateSenha("senha1@3$"), erro);
    }

    @Test
    void validateSenhaGrandeComLetraNumeroESemCaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida não tem caracteres especiais");
        assertEquals(CadastroValidator.ValidateSenha("senha1234"), erro);
    }

    @Test
    void validateSenhaGrandeSemNumeroEComLetraECaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida não tem numeros");
        assertEquals(CadastroValidator.ValidateSenha("senha!@#$"), erro);
    }

    @Test
    void validateSenhaGrandeComLetraSemNumeroECaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida não tem numeros");
        erro.add("A senha inserida não tem caracteres especiais");
        assertEquals(CadastroValidator.ValidateSenha("minhasenha"), erro);
    }

    @Test
    void validateSenhaGrandeComnumeroECaracterEspecialSemLetra() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida não tem letras");
        assertEquals(CadastroValidator.ValidateSenha("12345!@#$%"), erro);
    }

    @Test
    void validateSenhaGrandeComnumeroSemLetraECaracterEspecial() {
        ArrayList<String> erro = new ArrayList<>(); 
        erro.add("A senha inserida não tem letras");
        erro.add("A senha inserida não tem caracteres especiais");
        assertEquals(CadastroValidator.ValidateSenha("12345678910"), erro);
    }
}