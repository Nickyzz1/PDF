package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Mensagem;
import com.desktopapp.model.Sessao;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class InicialScreenController {

    public static Scene CreateScene(String nameUser, String emailSessao) throws Exception {
        URL sceneUrl = InicialScreenController.class
                .getResource("InicialScreen.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

       InicialScreenController controller = loader.getController();

       controller.nomeUser.setText(nameUser);
       controller.setEmailUser(emailSessao);


        return scene;
    }

    private String emailSessao;
    private String nameUser;

    
    @FXML
    protected TableView<Mensagem> tabela;
    
    @FXML
    private TableColumn<Mensagem, Void> abrirMsg;
    
    @FXML
    protected TableColumn<Mensagem, String> tituloMsg;
    
    @FXML
    protected TableColumn<Mensagem, String> emailMsg;
    
    @FXML
    protected Button enviarMsg;
    
    @FXML
    protected Button logout;
    
    @FXML
    protected Label nomeUser;
    
    @FXML
    protected void logout(ActionEvent e) throws Exception {
        var stage = (Stage) logout.getScene().getWindow();
        var scene = LoginScreenController.CreateScene();
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    protected void enviarMsg(ActionEvent e) throws Exception {
        var stage = (Stage) enviarMsg.getScene().getWindow();
        var scene = MensagemScreenController.CreateScene(emailSessao);
        stage.setScene(scene);
        stage.show();
    }
    
    @FXML
    public void initialize() {
        Context ctx = new Context();
        Sessao sessao = new Sessao();
        
        
        
        
        nomeUser.setText("Olá " + emailSessao);

        
        
        emailMsg.setCellValueFactory(new PropertyValueFactory<>("recebido"));
        tituloMsg.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        
        abrirMsg.setCellFactory(column -> new TableCell<Mensagem, Void>() {
            private final Button abrirButton = new Button("Abrir");
            
            {
                abrirButton.setOnAction(event -> {
                    
                    Mensagem msg = getTableView().getItems().get(getIndex());
                    Alert alert = new Alert(AlertType.NONE);
                    alert.setTitle(msg.getTitulo());
                    alert.setHeaderText(String.valueOf(nomeUser));
                    alert.setContentText(msg.getMensagem());
                    alert.getButtonTypes().setAll(javafx.scene.control.ButtonType.CLOSE);
                    
                    alert.showAndWait();
                    
                });
            }
            
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : abrirButton);
            }
        });
        
        tabela.setItems(ctx.listaMensagem());
    }
    
    public String getNameUser() {
        return nameUser;
    }
    
    public void setNameUser(String nameUser) {
        this.nameUser = nameUser;
    }
    
    public String getEmailSessao() { 
        return emailSessao;
    }
    
    public void setEmailUser(String emailSessao) {
        this.emailSessao = emailSessao;
    }
}
