package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Mensagem;
import com.desktopapp.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MensagemScreenController {
    public static Scene CreateScene(String emailUser) throws Exception {
        URL sceneUrl = MensagemScreenController.class
        .getResource("MensagemScreen.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        MensagemScreenController controller = loader.getController();

        controller.setEmailUser(emailUser);

        return scene;
    }

    private String nomeUser;
    private String emailUser;
    
    public String getNomeUser() {
        return nomeUser;
    }

    public void setNomeUser(String nomeUser) {
        this.nomeUser = nomeUser;
    }

    public String getEmailUser() {
        return emailUser;
    }

    public void setEmailUser(String emailUser) {
        this.emailUser = emailUser;
    }

    @FXML
    protected Button enviarmsg;
    
    @FXML
    protected Button voltar;
    
    @FXML
    protected TextField tituloMsg;
    
    @FXML
    protected TextField emailMsg;
    
    @FXML
    protected TextArea msg;

    @FXML
    protected void enviarMsg(ActionEvent e) throws Exception {
        
        Context ctx = new Context();

        Mensagem mensa = new Mensagem();

        var email = ctx.find(User.class,
                "SELECT u FROM User u WHERE u.email = :arg0",
                emailMsg.getText());

        if (email == null) {
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "Email não existe!",
                    ButtonType.OK);
            alert.showAndWait();
            return;
        }

        mensa.setTitulo(tituloMsg.getText());
        mensa.setRecebido(emailMsg.getText());
        mensa.setMensagem(msg.getText());
        mensa.setEnviado(emailUser);


        ctx.begin();
        ctx.save(mensa);
        ctx.commit();
        
        var crrStage = (Stage) enviarmsg
                .getScene().getWindow();
        crrStage.close();
        var stage = new Stage();
        var scene = MensagemScreenController.CreateScene(emailUser);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    protected void voltar(ActionEvent e) throws Exception {
        var stage = (Stage) voltar.getScene().getWindow(); 
        var scene = InicialScreenController.CreateScene(nomeUser, emailUser);
        stage.setScene(scene);
        stage.show(); 
    }

}