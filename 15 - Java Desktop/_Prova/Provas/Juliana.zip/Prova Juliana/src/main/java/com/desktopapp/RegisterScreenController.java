package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class RegisterScreenController {
    public static Scene CreateScene() throws Exception {
        URL sceneUrl = LoginScreenController.class
                .getResource("RegisterScreen.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }

    @FXML
    protected Button registerCreate;
    
    @FXML
    protected TextField nameCreate;
    
    @FXML
    protected TextField emailCreate;
    
    @FXML
    protected PasswordField passwordCreate;

    @FXML
    protected PasswordField passwordCreate1;

    @FXML
    protected void register(ActionEvent e) throws Exception {
        
        Context ctx = new Context();

        var name = ctx.find(User.class,
                "SELECT u FROM User u WHERE u.name = :arg0",
                nameCreate.getText());
        
        var email = ctx.find(User.class,
                "SELECT u FROM User u WHERE u.email = :arg0",
                emailCreate.getText());

        if (!name.isEmpty()) {
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "Usuário já está cadastrado!",
                    ButtonType.OK);
            alert.showAndWait();
            return;
        }
        
        if (!email.isEmpty()) {
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "Email já está cadastrado!",
                    ButtonType.OK);
            alert.showAndWait();
            return;
        }

        if (!passwordCreate.getText().equals(passwordCreate1.getText())) {
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "As senhas precisam ser iguais!",
                    ButtonType.OK);
            alert.showAndWait();
            return;
        }

        
        User user = new User();
        user.setName(nameCreate.getText());
        user.setPassword(passwordCreate.getText());
        user.setEmail(emailCreate.getText());
        
        ctx.begin();
        ctx.save(user);
        ctx.commit();
        
        var crrStage = (Stage) registerCreate
                .getScene().getWindow();
        crrStage.close();
        var stage = new Stage();
        var scene = LoginScreenController.CreateScene();
        stage.setScene(scene);
        stage.show();

    }
}