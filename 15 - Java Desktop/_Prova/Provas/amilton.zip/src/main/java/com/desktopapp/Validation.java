package com.desktopapp;

import org.hibernate.mapping.List;

import com.desktopapp.model.User;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Validation {

    Alert alert = new Alert(null);

    private Boolean flagSpecChar = false;
    private Boolean flagNumber = false;
    
    public Validation() {}

    protected void Erro(String message) {

    }

    ObservableList<String> specChar = FXCollections.observableArrayList("@", "_", "-", "!", "#", "%", "<", ">", "?", "*", "&");

    protected Boolean verifyPassword(PasswordField newUserPassword, PasswordField passwordConfirm) {
        if (newUserPassword.getText().length() >= 8)

            if (newUserPassword.getText().equals(passwordConfirm.getText())) {

                for (int i = 0; i < newUserPassword.getText().length(); i++) {
                    for (int j = 0; j < specChar.size(); j++) {
                        if (newUserPassword.getText().contains(specChar.get(j))) {
                            flagSpecChar = true;
                        }
                    }
                }

                for (int i = 0; i < newUserPassword.getText().length(); i++) {

                    Integer compare = i;
                    if (newUserPassword.getText().contains(compare.toString())) {
                        flagNumber = true;
                    }
                }

                if (flagSpecChar && flagNumber) {
                    return true;
                } else {
                    alert.setAlertType(AlertType.ERROR);
                    alert.setContentText("Sua senha deve conter ao menos 1 número, um caractere especial e no mínimo 8 caracteres!");
                    alert.setHeaderText("Erro!");
            
                    alert.showAndWait();
                }
            } else {
                alert.setAlertType(AlertType.ERROR);
                alert.setContentText("Suas senhas devem ser iguais!");
                alert.setHeaderText("Erro!");

                alert.showAndWait();
                return false;
            }
        
        alert.setAlertType(AlertType.ERROR);
        alert.setContentText("Sua senha deve conter ao menos 1 número, um caractere especial e no mínimo 8 caracteres!");
        alert.setHeaderText("Erro!");

        alert.showAndWait();

        return false;
    }

    protected Boolean verifyEmail(TextField newUserEmail) {
        if (newUserEmail.getText().contains("@") && newUserEmail.getText().endsWith(".com"))
            return true;
        
        return false;
    }

    protected Boolean verifyUser(TextField newUserName, TextField newUserEmail) {
        Context ctx =  new Context();

        ctx.begin();

        var query =  ctx.createQuery(User.class, "from User where name = :name OR email = :email");
        query.setParameter("name", newUserName.getText());
        query.setParameter("email", newUserEmail.getText());
        var users = query.getResultList();

        if (users.size() > 0) {
            return false;
        } else {
            return true;
        }
    }

    protected Boolean verifyRegister(TextField newUserName, TextField newUserEmail, PasswordField newUserPassword, PasswordField passwordConfirm) {
        if (newUserName.getText().equals("") || newUserEmail.getText().equals("") || newUserPassword.getText().equals("") || passwordConfirm.getText().equals("")) {
            
            alert.setAlertType(AlertType.ERROR);
            alert.setContentText("Preencha os campos corretamente!");
            alert.setHeaderText("Erro!");
            alert.showAndWait();

            return false;
        } else {
            
            if (verifyUser(newUserName, newUserEmail)) {

                if (verifyEmail(newUserEmail)) {

                    if (verifyPassword(newUserPassword, passwordConfirm)) {
                        return true;
                    } else {
                        return false;
                    }

                } else {

                    alert.setAlertType(AlertType.ERROR);
                    alert.setContentText("Formato de e-mail inválido. Formato correto: \"email@email.com!\"");
                    alert.setHeaderText("Erro!");

                    alert.showAndWait();
                    return false;
                }
                
            } else {
                alert.setAlertType(AlertType.ERROR);
                alert.setContentText("Já existe um usuário com este e-mail ou/e nome!");
                alert.setHeaderText("Erro!");

                alert.showAndWait();
                return false;
            }    
        }
    }
}
