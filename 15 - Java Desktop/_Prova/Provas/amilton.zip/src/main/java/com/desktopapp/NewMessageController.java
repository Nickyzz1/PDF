package com.desktopapp;

import com.desktopapp.model.User;
import com.desktopapp.model.Message;

import java.net.URL;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.text.Text;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class NewMessageController {

    private Alert alert = new Alert(null);
    private static User sendUser;

    public static Scene CreateScene(User usuario) throws Exception
    {
        URL sceneUrl = MainController.class
            .getResource("NewMessage.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        sendUser = usuario;
        
        return scene;
    }

    @FXML
    protected TextField sentToEmail;

    @FXML
    protected TextField messageTitle;

    @FXML
    protected TextArea messageBox;

    @FXML
    protected Button sendMessageBtttn;

    @FXML
    protected void sendMessage() {

        if (sentToEmail.getText().equals("") || messageBox.getText().equals("") || messageTitle.getText().equals("")) {
            alert.setAlertType(AlertType.ERROR);
            alert.setContentText("Preencha os campos corretamente!");
            alert.setHeaderText("Erro!");
            alert.showAndWait();
        } else {

            Context ctx =  new Context();

            ctx.begin();

            var query =  ctx.createQuery(User.class, "from User where email = :email");
            query.setParameter("email", this.sentToEmail.getText());
            var users = query.getResultList();

            if (users.size() == 0) {
                alert.setAlertType(AlertType.ERROR);
                alert.setContentText("Usuário não encontrado!");
                alert.setHeaderText("Erro!");
                alert.showAndWait();
            } else {
                Message message = new Message();

                message.setSentFrom(sendUser.getEmail());
                message.setTitle(messageTitle.getText());
                message.setSentTo(sentToEmail.getText());
                message.setMessage(messageBox.getText());

                ctx.save(message);
                ctx.commit();

                alert.setAlertType(AlertType.CONFIRMATION);
                alert.setContentText("Mensagem enviada com sucesso!");
                alert.setHeaderText("Você enviou uma mensagem para " + users.get(0).getName() + "!");
    
                alert.showAndWait();
            }
        }
    }
}
