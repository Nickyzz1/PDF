package com.desktopapp.repositories;

import com.desktopapp.model.User;

public interface UserRepository {
    void update(User user);
    void delete(User user);
}