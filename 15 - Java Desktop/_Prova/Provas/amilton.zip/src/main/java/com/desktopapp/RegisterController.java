package com.desktopapp;

import java.net.URL;
import java.util.ResourceBundle;

import com.desktopapp.model.User;

import jakarta.persistence.EntityManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class RegisterController implements Initializable {

    private Alert alert = new Alert(null);

    public static Scene CreateScene() throws Exception
    {
        URL sceneUrl = MainController.class
            .getResource("RegisterScene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        return scene;
    }

    @FXML
    protected Button bttnRegister;

    @FXML
    public PasswordField newUserPassword;

    @FXML
    public PasswordField passwordConfirm;

    @FXML
    public TextField newUserName;

    @FXML
    public TextField newUserEmail;

    @FXML
    protected void registrarUsuario() throws Exception {

        System.out.println(this.newUserName.getText());

            Validation validation = new Validation();

            if (validation.verifyRegister(newUserName, newUserEmail, newUserPassword, passwordConfirm)) {

                Context ctx = new Context();
    
                User newUser = new User();
    
                newUser.setEmail(newUserEmail.getText());
                newUser.setName(newUserName.getText());
                newUser.setPassword(newUserPassword.getText());
    
                ctx.begin();
                ctx.save(newUser);
                ctx.commit();
    
                alert.setAlertType(AlertType.CONFIRMATION);
                alert.setContentText("Usuário criado com sucesso!");
                alert.setHeaderText("Bem vindo " + this.newUserName.getText() + "!");
    
                alert.showAndWait();
                loginPage();
            }
    }

    @FXML
    protected void loginPage() throws Exception {
        Stage crrStage = (Stage)bttnRegister.getScene().getWindow();

        Scene newScene = MainController.CreateScene();
        crrStage.setScene(newScene);
        crrStage.show();
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

    }
}
