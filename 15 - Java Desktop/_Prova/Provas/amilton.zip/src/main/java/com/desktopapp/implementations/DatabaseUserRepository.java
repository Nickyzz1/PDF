package com.desktopapp.implementations;

import com.desktopapp.Context;
import com.desktopapp.model.User;
import com.desktopapp.repositories.UserRepository;

public class DatabaseUserRepository implements UserRepository {
    @Override
    public void update(User user) {
        Context ctx = new Context();
        ctx.begin();
        ctx.update(user);
        ctx.commit();
    }

    @Override
    public void delete(User user) {
        Context ctx = new Context();
        ctx.begin();
        ctx.delete(user);
        ctx.commit();
    }
}