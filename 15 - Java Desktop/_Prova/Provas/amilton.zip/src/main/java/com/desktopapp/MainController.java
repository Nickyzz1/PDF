package com.desktopapp;
import java.net.URL;

import com.desktopapp.model.User;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.*;
import javafx.stage.Stage;

public class MainController {

    private Alert alert = new Alert(null);

    public static Scene CreateScene() throws Exception
    {
        User usuario =  new User();
        Context ctx = new Context();

        ctx.begin();

        usuario.setName("adm");
        usuario.setPassword("123");
        usuario.setEmail("email@email.com");
        usuario.setId(1l);

        ctx.delete(usuario);
        ctx.commit();

        URL sceneUrl = MainController.class
            .getResource("LoginScene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);        

        return scene;
    }

    @FXML
    private TextField loginInput;

    @FXML
    private PasswordField passwordInput;

    @FXML
    private Button bttnRegister;

    @FXML
    private Button bttnLogin;

    @FXML
    private void login(MouseEvent e) throws Exception {

        Context ctx =  new Context();

        ctx.begin();

        var query =  ctx.createQuery(User.class, "from User where name = :name OR email = :email");
        query.setParameter("name", this.loginInput.getText());
        query.setParameter("email", this.loginInput.getText());
        var users = query.getResultList();

        if (users.size() > 0) {
            
            if (users.get(0).getPassword().equals(this.passwordInput.getText())) {

                alert.setAlertType(AlertType.CONFIRMATION);
                alert.setContentText("Logado com sucesso!");
                alert.setHeaderText("Olá, " + users.get(0).getName() + "!");
                alert.setResult(ButtonType.OK);

                alert.showAndWait();

                Stage crrStage = (Stage)bttnLogin.getScene().getWindow();
                Scene newScene = MessagesController.CreateScene(users.get(0));
                crrStage.setScene(newScene);
                crrStage.show();
                
            } else {

                alert.setAlertType(AlertType.ERROR);
                alert.setContentText("Senha incorreta!");
                alert.setHeaderText("Erro!");
                alert.setResult(ButtonType.CLOSE);

                alert.showAndWait();
            }
        } else {

            alert.setAlertType(AlertType.ERROR);
            alert.setContentText("Usuário não encontrado!");
            alert.setHeaderText("Erro!");
            alert.setResult(ButtonType.CLOSE);

            alert.showAndWait();
        }
    }

    @FXML
    private void openRegisterScene(MouseEvent e) throws Exception {
        Stage crrStage = (Stage)bttnRegister.getScene().getWindow();
        URL sceneUrl = RegisterController.class
            .getResource("RegisterScene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);      

        crrStage.setScene(scene);
    }

}
