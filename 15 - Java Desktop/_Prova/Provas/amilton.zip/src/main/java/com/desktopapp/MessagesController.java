package com.desktopapp;

import java.net.URL;
import java.util.ResourceBundle;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MessagesController {

    private User loggedUser;

    private ObservableList<Message> Lista = FXCollections.observableArrayList();

    public static Scene CreateScene(User usuario) throws Exception
    {
        URL sceneUrl = MainController.class
            .getResource("MessagesScene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        MessagesController controller = loader.getController();

        controller.helloUserLabel.setText("Olá, " + usuario.getName());

        controller.loggedUser = usuario;

        // controller.messages();

        // controller.messagesTable.setItems(controller.Lista);
        
        return scene;
    }

    @FXML
    protected Button bttnNewMessage;

    @FXML
    protected Text helloUserLabel;

    @FXML
    protected Text newMessagesLabel;

    @FXML
    protected ScrollPane messagesScrollPanel;

    @FXML
    protected Button bttnLogout;

    @FXML
    protected TableView<Message> messagesTable;

    @FXML
    protected TableColumn<Message, String> nameCol;

    @FXML
    protected TableColumn<Message, String> TitleCol;

    @FXML
    public void logoff() throws Exception {
        Stage crrStage = (Stage)bttnLogout.getScene().getWindow();
        Scene newScene = MainController.CreateScene();
        
        crrStage.setScene(newScene);
        crrStage.show();
    }

    @FXML
    public void sendNewMessage() throws Exception {
       Stage newStage = new Stage();

       Scene newScene = NewMessageController.CreateScene(loggedUser);
       newStage.setScene(newScene);
       newStage.show();
    }

    // public ObservableList<Message> messages() {

    //     Context ctx = new Context();
    //     var query =  ctx.createQuery(Message.class, "from Message where email = :email");
    //     query.setParameter("email", this.loggedUser.getEmail());
    //     var users = query.getResultList();

    //     Lista = (ObservableList<Message>) users;

    //     return Lista;
    // }

}
