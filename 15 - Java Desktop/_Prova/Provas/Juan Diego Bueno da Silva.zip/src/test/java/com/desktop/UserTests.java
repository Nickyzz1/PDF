package com.desktop;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.desktop.Tools.Auth;

public class UserTests {

    @Test
    void validatePassword(){
        assertEquals(Auth.AuthPassword("AAA", "AAA"),false);
        assertEquals(Auth.AuthPassword("ABCDEFGH", "ABCDEFGH"),false);
        assertEquals(Auth.AuthPassword("12345678", "12345678"),false);
        assertEquals(Auth.AuthPassword("23asd213", "12345678"),false);
        assertEquals(Auth.AuthPassword("23asd213", "23asd213"),false);
        assertEquals(Auth.AuthPassword("AAA@AAA2", "AAA@AAA2"),true);
    }

    @Test
    void validateEmail(){
        assertEquals(Auth.AuthEmail("AAA"),false);
        assertEquals(Auth.AuthEmail("AAA@AAA"),false);
        assertEquals(Auth.AuthEmail("AAA@AAA.com"),true);
    }
}