package com.desktop;

import java.net.URL;

import com.desktop.Tools.Auth;
import com.desktop.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class LoginController {

    public static Scene CreateScene() throws Exception{
    URL sceneUrl = LoginController.class
        .getResource("login.fxml");

    FXMLLoader loader = new FXMLLoader(sceneUrl);
    Parent root = loader.load();
    Scene scene = new Scene(root);

    return scene;
    }  
    
    @FXML
    protected Button btLogin;

    @FXML
    protected Button btCreate;

    @FXML
    protected TextField txEmail;

    @FXML
    protected PasswordField txPassword;

    @FXML
    protected void CreateAcount(ActionEvent e) throws Exception{
        Stage currentStage = (Stage)this.btLogin.getScene().getWindow();
        Scene newScene = CreateLoginController.CreateScene();
        currentStage.setScene(newScene);
    }

    @FXML
    protected void submit(MouseEvent e) throws Exception{

        var user = Auth.GetUser(this.txEmail.getText());

        if(user == null){
            Alert alert = new Alert(AlertType.ERROR,"Usuario não encontrado!!",ButtonType.OK);
            alert.showAndWait();
            return;
        }

        if(!user.getPassword().equals(txPassword.getText())){
            Alert alert = new Alert(AlertType.ERROR,"Senha Incorreta!!",ButtonType.OK);
            alert.showAndWait();
            return;
        }
            
        Stage currentStage = (Stage)this.btLogin.getScene().getWindow();
        Scene newScene = MainController.CreateScene(user);
        currentStage.setScene(newScene);
    }
}
