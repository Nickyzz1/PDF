package com.desktop.Tools;


import com.desktop.GetEmailController;
import com.desktop.LoginController;
import com.desktop.model.Email;
import com.desktop.model.User;

import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class TableOp extends Email{
    public TableOp(Email email){
        this.setId(email.getId());
        this.setTitle(email.getTitle());
        this.setMessage(email.getMessage());

        Context ctx = new Context();

        User origin = ctx.find(User.class,email.getIdOrigin());

        this.Origin = origin.getEmail();

        this.BtGet = new Button("Ver");
        BtGet.setOnAction((ActionEvent event)->{
            try {
                Scene newScene = GetEmailController.CreateScene(this.getTitle(),email.getMessage(),this.Origin,origin.getName());
                Stage newStage = new Stage();
                newStage.setScene(newScene);
                newStage.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        });
    
    }
    
    private Button BtGet;

    public Button getBtGet() {
        return BtGet;
    }

    public void setBtGet(Button btGet) {
        BtGet = btGet;
    }

    private String Origin;

    public String getOrigin() {
        return Origin;
    }

    public void setOrigin(String origin) {
        Origin = origin;
    }
}
