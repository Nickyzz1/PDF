package com.desktop.Tools;


import java.util.ArrayList;
import java.util.List;

import com.desktop.model.User;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;


public class Auth {
    public static User GetUser(String user) {
        Context ctx = new Context();
        var User = ctx.find(User.class, "SELECT u FROM User u WHERE u.name = :arg0 OR u.email = :arg0",user);
        return User.isEmpty()?null:User.get(0);
    }

    public static boolean ExistUser(String user){
        return GetUser(user) != null?true:false;
    }

    public static boolean AuthEmail(String email){

        if(GetUser(email) != null) return false;

        try {
            var text = email.split("@");
            if(text[1].contains(".")){
                return true;
            }
            return false;
            
        } catch (Exception e) {
            return false;
        }

    }

    public static boolean AuthPassword(String password1,String password2){
        if(password1.length()<8) return false;

        if(!password1.equals(password2)) return false;

        System.out.println(password1.contains("@\\?\\!\\#\\%"));
        if(!password1.contains("@/?/!/#/%/"))return false;   
        if (!(password1.contains("1") || password1.contains("2") || password1.contains("3") || password1.contains("4") || password1.contains("5") || password1.contains("6") || password1.contains("7") || password1.contains("8") || password1.contains("9"))) return false;

        return true;
    }

    public static List<Alert> AuthNewUser(String user,String email,String password1,String password2){
        List<Alert> list = new ArrayList<>();

        if(Auth.ExistUser(user)){
            list.add(new Alert(AlertType.ERROR,"Usuario ja Existente!!",ButtonType.OK));
        }

        if (!AuthEmail(email)) {
            list.add(new Alert(AlertType.ERROR,"Email Invalido ou Ja utilizado!!",ButtonType.OK));
        }

        if (!AuthPassword(password1,password2)) {
            list.add(new Alert(AlertType.ERROR,"Senha Invalida ou Campos Diferentes!!",ButtonType.OK));
        }

        return list.size()>0?list:null;
    }   
}
