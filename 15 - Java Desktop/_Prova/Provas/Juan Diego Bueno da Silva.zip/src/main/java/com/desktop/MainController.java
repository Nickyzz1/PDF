package com.desktop;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import com.desktop.Tools.Context;
import com.desktop.Tools.TableOp;
import com.desktop.model.Email;
import com.desktop.model.User;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MainController implements Initializable{

    public static Scene CreateScene(User user) throws Exception{
        URL sceneUrl = CreateLoginController.class
            .getResource("Main.fxml");
    
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        MainController controller = loader.getController();
        controller.setUser(user);
        controller.txtHello.setText("Ola "+user.getName());
        controller.SetList();


        
        Timer timero = new Timer();
        timero.scheduleAtFixedRate(new TimerTask() {
            Context ctx = new Context();
            Integer size = controller.SetList();
            @Override
            public void run(){
                if(size!= ctx.find(Email.class, "SELECT e FROM Email e WHERE e.idDestiny = :arg0",user.getId()).size()){
                    controller.SetList();
                }
            }
        }, 1000, 1000);
    
        return scene;
    }  

    private User user;

    public User getUser() {
        return user;
    }


    public void setUser(User user) {
        this.user = user;
    }

    @FXML
    protected Text txtHello;

    @FXML
    protected Button NewEmail;

    @FXML
    protected Button BtLogout;

    @FXML
    protected TableView<TableOp> TbEmail;

    @FXML
    protected TableColumn<TableOp,Long> TbId;

    @FXML
    protected TableColumn<TableOp,String> TbOrigin;

    @FXML
    protected TableColumn<TableOp,Float> TbTitle;

    @FXML
    protected TableColumn<TableOp,Float> TbOp;


    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        TbId.setCellValueFactory(new PropertyValueFactory<>("id"));
        TbOrigin.setCellValueFactory(new PropertyValueFactory<>("Origin"));
        TbTitle.setCellValueFactory(new PropertyValueFactory<>("Title"));
        TbOp.setCellValueFactory(new PropertyValueFactory<>("BtGet"));

    }

    protected Integer SetList(){
        Context ctx = new Context();

        var list = ctx.find(Email.class, "SELECT e FROM Email e WHERE e.idDestiny = :arg0",user.getId());

        if(list.isEmpty())return 0;

        var especial = list.stream()
            .map(e->new TableOp(e))
            .collect(Collectors.toList());
        
        TbEmail.setItems(FXCollections.observableList(especial));
        return especial.size();
    }

    
    @FXML
    protected void NewEmail(ActionEvent e) throws Exception{

        Stage currentStage = (Stage)this.BtLogout.getScene().getWindow();
        Scene newScene = EmailController.CreateScene(this.user);
        currentStage.setScene(newScene);
    }

    @FXML
    protected void Logout(ActionEvent e )throws Exception{
        Stage currentStage = (Stage)this.BtLogout.getScene().getWindow();
        Scene newScene = LoginController.CreateScene();
        currentStage.setScene(newScene);
    }
}

