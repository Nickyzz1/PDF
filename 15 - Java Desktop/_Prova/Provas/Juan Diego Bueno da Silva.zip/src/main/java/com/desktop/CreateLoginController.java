package com.desktop;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;

import com.desktop.Tools.Auth;
import com.desktop.Tools.Context;
import com.desktop.model.User;



public class CreateLoginController {

    public static Scene CreateScene() throws Exception{
    URL sceneUrl = CreateLoginController.class
        .getResource("CreateLogin.fxml");

    FXMLLoader loader = new FXMLLoader(sceneUrl);
    Parent root = loader.load();
    Scene scene = new Scene(root);

    return scene;
    }  
    

    @FXML
    protected Button btCreate;

    @FXML
    protected TextField txEmail;

    @FXML
    protected PasswordField txPassword;

    @FXML
    protected PasswordField txPassword1;

    @FXML
    protected TextField txName;

    @FXML
    protected Button btBack;


    @FXML
    protected void CreateAcount(ActionEvent e) throws Exception{

        var alerts = Auth.AuthNewUser(txName.getText(), txEmail.getText(), txPassword.getText(), txPassword1.getText());
        
        if(alerts!=null){
            for (Alert alert : alerts) {
                alert.showAndWait();
            }
            return;
        }

        User user = new User();
        user.setName(txName.getText());
        user.setEmail(txEmail.getText());
        user.setPassword(txPassword.getText());
    
        Context ctx = new Context();
        ctx.begin();
        ctx.save(user);
        ctx.commit();

        Stage currentStage = (Stage)this.btCreate.getScene().getWindow();
        Scene newScene = LoginController.CreateScene();
        currentStage.setScene(newScene);
    }

    @FXML
    protected void Back(ActionEvent e) throws Exception{
        Stage currentStage = (Stage)this.btCreate.getScene().getWindow();
        Scene newScene = LoginController.CreateScene();
        currentStage.setScene(newScene);
    }
}
