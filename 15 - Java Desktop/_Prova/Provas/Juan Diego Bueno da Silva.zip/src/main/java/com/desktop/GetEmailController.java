package com.desktop;

import java.net.URL;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;

public class GetEmailController {

    public static Scene CreateScene(String title,String message,String origin,String name) throws Exception{
    URL sceneUrl = GetEmailController.class
        .getResource("GetEmail.fxml");

    FXMLLoader loader = new FXMLLoader(sceneUrl);
    Parent root = loader.load();
    Scene scene = new Scene(root);

    GetEmailController controller = loader.getController();

    controller.txTitle.setText(title);
    controller.txOrigin.setText("Email: "+origin);
    controller.txMessage.setText(message);
    controller.txName.setText("nome: "+name);

    return scene;
    } 


    @FXML
    protected Text txTitle;

    @FXML
    protected Text txOrigin;

    @FXML
    protected Text txName;

    @FXML
    protected Text txMessage;

}
