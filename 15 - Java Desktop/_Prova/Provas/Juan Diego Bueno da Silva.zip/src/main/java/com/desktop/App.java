package com.desktop;


import com.desktop.Tools.Context;
import com.desktop.model.User;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class App extends Application
{
    public static void main(String[] args){
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        User user = new User();
        user.setName("a");
        user.setEmail("a@a");
        user.setPassword("a");

        Context ctx = new Context();
        ctx.begin();
        ctx.save(user);
        ctx.commit();

        Scene scene = LoginController.CreateScene();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}