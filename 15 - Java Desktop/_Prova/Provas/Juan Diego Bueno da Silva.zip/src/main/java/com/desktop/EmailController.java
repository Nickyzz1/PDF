package com.desktop;

import java.net.URL;

import com.desktop.Tools.Auth;
import com.desktop.Tools.Context;
import com.desktop.model.Email;
import com.desktop.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EmailController {
        public static Scene CreateScene(User user) throws Exception{
    URL sceneUrl = CreateLoginController.class
        .getResource("Email.fxml");

    FXMLLoader loader = new FXMLLoader(sceneUrl);
    Parent root = loader.load();
    Scene scene = new Scene(root);

    EmailController controller = loader.getController();
    controller.setUser(user);

    return scene;
    }  
    

    private User user;


    public User getUser() {
        return user;
    }


    public void setUser(User user) {
        this.user = user;
    }


    @FXML
    protected Button btSend;

    @FXML
    protected TextField txEmail;

    @FXML
    protected TextField txTitle;

    @FXML
    protected TextField txMessage;


    @FXML
    protected void SendEmail(ActionEvent e) throws Exception{
        var userDestiny = Auth.GetUser(txEmail.getText());

        if(userDestiny == null){
            Alert a = new Alert(AlertType.ERROR,"Usuario não encontrado!!",ButtonType.OK);
            a.showAndWait();
            return;
        }

        Email email = new Email();

        email.setIdOrigin(this.user.getId());
        email.setIdDestiny(userDestiny.getId());
        email.setTitle(txTitle.getText());
        email.setMessage(txMessage.getText());

        Context ctx = new Context();

        ctx.begin();
        ctx.save(email);
        ctx.commit();

        Stage currentStage = (Stage)this.btSend.getScene().getWindow();
        Scene newScene = MainController.CreateScene(this.user);
        currentStage.setScene(newScene);

    }
}
