package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Produto;
import com.desktopapp.model.User;

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;


public class MarketSceneController {

    public String nomi;

    public static Scene CreateScene(String login) throws Exception {
        URL sceneUrl = MarketSceneController.class
                .getResource("MarketScreen.fxml"); 
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        MarketSceneController controller = loader.getController();

        controller.texto.setText("Ola, " + login);

        controller.nomi = login;


        return scene;
    }

    @FXML
    protected Button newProduct;

    @FXML
    protected Label texto;

    @FXML
    protected Button myProduct;

    @FXML
    protected Button goHome;

    // @FXML
    // public void initialize() {
    //     Context ctx = new Context();

    //     var user = 
    // }


    @FXML
    protected void novoproduto(MouseEvent e) throws Exception {
        Stage crrStage = (Stage)newProduct
            .getScene()
            .getWindow();
        
        Scene newScene = NewProductSceneController.CreateScene(nomi);
        crrStage.setScene(newScene);
    }

    @FXML
    protected void casa(MouseEvent e) throws Exception {
        Stage crrStage = (Stage)goHome
            .getScene()
            .getWindow();
        
        Scene newScene = HomeSceneController.CreateScene();
        crrStage.setScene(newScene);
    }

    @FXML
    protected void meusprodutos(MouseEvent e) throws Exception {
        Stage crrStage = (Stage)myProduct
            .getScene()
            .getWindow();
        
        Scene newScene = MyProductSceneController.CreateScene(nomi);
        crrStage.setScene(newScene);
    }

}