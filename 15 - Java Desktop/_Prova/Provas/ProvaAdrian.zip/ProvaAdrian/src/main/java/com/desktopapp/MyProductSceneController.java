package com.desktopapp;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.util.Callback;
import javafx.util.StringConverter;
import javafx.util.converter.IntegerStringConverter;

import com.desktopapp.model.Produto;
import com.desktopapp.model.User;

import jakarta.persistence.TypedQuery;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

public class MyProductSceneController {

    public String nomi;

    public static Scene CreateScene(String login) throws Exception {
        URL sceneUrl = MyProductSceneController.class
                .getResource("MyProductScreen.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        MyProductSceneController controller = loader.getController();

        controller.nomi = login;

        Context ctx = new Context();

        var users = ctx.find(User.class, "SELECT u FROM User u WHERE u.name = :arg0", login);

        System.out.println(users);

        var eba = users.get(0).getId();

        System.out.println(eba);

        var titulos = ctx.find(Produto.class, "SELECT title FROM Produto u WHERE u.idUser = :arg0", eba);

        System.out.println(titulos);
        
        controller.colProduto.setCellValueFactory(new PropertyValueFactory<>("title"));
        controller.colStatus.setCellValueFactory(new PropertyValueFactory<>("nome"));
        controller.colPreco.setCellValueFactory(new PropertyValueFactory<>("msg"));


        List<Produto> UserMsg = ctx.find(Produto.class,
                "select u from Produto u where u.idUser = :arg0", eba);

        System.out.println(UserMsg);

        

        ObservableList<Produto> msgList = FXCollections.observableArrayList(UserMsg);
        controller.tabela.setItems(msgList);
        return scene;
    }

    @FXML
    protected Button goHome;

    @FXML
    protected Button lupa;

    @FXML
    protected TextField search;

    @FXML
    protected TableView<Produto> tabela;

    @FXML
    protected TableColumn<Produto, String> colPreco;

    @FXML
    protected TableColumn<Produto, Integer> colStatus;

    @FXML
    protected TableColumn<Produto, String> colProduto;

    @FXML
    protected TableColumn<Produto, String> colQtd;

    @FXML
    protected void inicio(MouseEvent e) throws Exception {
        Stage crrStage = (Stage) goHome
                .getScene()
                .getWindow();

        Scene newScene = MarketSceneController.CreateScene(nomi);
        crrStage.setScene(newScene);
    }
}