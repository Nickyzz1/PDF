package com.desktopapp;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import static com.desktopapp.RegisterValidator.*;

public class RegisterValidatorTest
{
    @Test
    void TestEmail()
    {
        assertEquals(ValidateEmail("name@email.com"), 0);
        assertEquals(ValidateEmail("name.name2@email.com"), 0);
        assertEquals(ValidateEmail("name.email@com"), 1);
        assertEquals(ValidateEmail("Bom dia"), 1);
    }
    
    @Test
    void TestPasswordMatch()
    {
        assertEquals(ValidatePassword("Bom.Dia1", "Bom.Dia1"), 0);
        assertEquals(ValidatePassword("BomDia", "bomdia"), 1);
        assertEquals(ValidatePassword("bom dia", "bomdia"), 1);
    }

    @Test
    void TestPasswordLength()
    {
        assertEquals(ValidatePassword("Bom.Dia1", "Bom.Dia1"), 0);
        assertEquals(ValidatePassword("F7xw-rtY24v2/pl", "F7xw-rtY24v2/pl"), 0);
        assertEquals(ValidatePassword("1.2a", "1.2a"), 2);
        assertEquals(ValidatePassword("a", "a"), 2);
    }

    @Test
    void TestPasswordContent()
    {
        assertEquals(ValidatePassword("Bom.Dia1", "Bom.Dia1"), 0);
        assertEquals(ValidatePassword("F7xw-rtY24v2/pl", "F7xw-rtY24v2/pl"), 0);
        assertEquals(ValidatePassword("1aaaaaaa", "1aaaaaaa"), 3);
        assertEquals(ValidatePassword(".aaaaaaa", ".aaaaaaa"), 3);
        assertEquals(ValidatePassword(".1.1.1.1", ".1.1.1.1"), 3);
    }
}