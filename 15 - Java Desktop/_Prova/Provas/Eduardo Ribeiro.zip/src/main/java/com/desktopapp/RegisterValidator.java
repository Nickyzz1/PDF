package com.desktopapp;

import java.util.ArrayList;

import com.desktopapp.model.User;
import jakarta.persistence.TypedQuery;

public class RegisterValidator
{
    public static int ValidatePassword(String Password1, String Password2)
    {
        if(!Password1.contentEquals(Password2))
        {
            return 1;
        }

        if(Password1.length() < 8)
        {
            return 2;
        }

        ArrayList<Character> Password = new ArrayList<>();

        for(int i = 0; i < Password1.length(); ++i)
        {
            Password.add(Password1.toCharArray()[i]);
        }

        long Special = Password.stream()
        .filter((c) ->
        {
            if
            (
                c == '/' ||
                c == '.' ||
                c == ',' ||
                c == '\\' ||
                c == '\"' ||
                c == '\'' ||
                c == '!' ||
                c == '@' ||
                c == '%' ||
                c == '$' ||
                c == '#' ||
                c == '*' ||
                c == '(' ||
                c == ')' ||
                c == '&' ||
                c == '+' ||
                c == '-' ||
                c == ':' ||
                c == ';' ||
                c == '?' ||
                c == '|' ||
                c == '{' ||
                c == '}' ||
                c == '[' ||
                c == ']' ||
                c == '|' ||
                c == '>' ||
                c == '<' ||
                c == '='
            )
            {
                return true;
            }
            return false;
        }).count();

        long Numbers = Password.stream()
        .filter((c) ->
        {
            if
            (
                c == '1' ||
                c == '2' ||
                c == '3' ||
                c == '4' ||
                c == '5' ||
                c == '6' ||
                c == '7' ||
                c == '8' ||
                c == '9' ||
                c == '0'
            )
            {
                return true;
            }
            return false;
        }).count();

        if(Numbers == 0 || Special == 0 || Numbers + Special >= Password.size())
        {
            return 3;
        }

        return 0;
    }

    public static int ValidateEmail(String Email)
    {
        int At = Email.indexOf("@");

        if(At >= 0 && Email.substring(At).indexOf(".") >= 0)
        {
            return 0;
        }
        return 1;
    }

    public static int ValidateEmailFull(String Email)
    {
        Context Ctx = new Context();
        TypedQuery<User> Query = Ctx.CreateQuery
        (
            User.class,
            "Select u From User u Where email = :email"
        );
        Query.setParameter("email", Email);
        
        if(Query.getResultList().size() > 0)
        {
            Ctx.Close();
            return 2;
        }

        return ValidateEmail(Email);
    }
    public static int ValidateName(String Name)
    {
        Context Ctx = new Context();
        TypedQuery<User> Query = Ctx.CreateQuery
        (
            User.class,
            "Select u From User u Where name = :name"
        );
        Query.setParameter("name", Name);
        
        if(Query.getResultList().size() > 0)
        {
            Ctx.Close();
            return 1;
        }
        return 0;
    }
}