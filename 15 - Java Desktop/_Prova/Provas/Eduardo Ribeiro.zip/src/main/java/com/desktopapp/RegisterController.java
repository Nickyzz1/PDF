package com.desktopapp;

import java.net.URL;
import java.util.ResourceBundle;

import com.desktopapp.model.User;

import static com.desktopapp.RegisterValidator.*;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class RegisterController implements Initializable
{
    public static Scene CreateScene() throws Exception
    {
        URL SceneUrl = RegisterController.class.getResource("RegisterWindow.fxml");
        FXMLLoader Loader = new FXMLLoader(SceneUrl);
        Parent Root = Loader.load();
        Scene Scene = new Scene(Root);
        return Scene;
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1)
    {

    }

    @FXML
    protected VBox Box;

    @FXML
    protected TextField TxtName;
    @FXML
    protected TextField TxtEmail;
    @FXML
    protected PasswordField TxtPassword1;
    @FXML
    protected PasswordField TxtPassword2;
    @FXML
    protected Button BtnRegister;
    @FXML
    protected Button BtnReturn;
    @FXML
    protected Label LblError;

    @FXML
    public void Register() throws Exception
    {
        String Name = TxtName.getText();
        String Email = TxtEmail.getText();
        String Password1 = TxtPassword1.getText();
        String Password2 = TxtPassword2.getText();

        if(Name.contentEquals("") || Email.contentEquals("") ||
        Password1.contentEquals("") || Password2.contentEquals(""))
        {
            LblError.setText("User data is incomplete");
            return;
        }

        if(ValidateName(Name) == 1)
        {
            LblError.setText("This name is already in use");
            return;
        }

        switch (ValidateEmailFull(Email))
        {
            case 1:
                LblError.setText("Incorrect email address");
            return;
            case 2:
                LblError.setText("This email is already in use");
            return;
            default:
            break;
        }

        switch (ValidatePassword(Password1, Password2))
        {
            case 1:
                LblError.setText("Passwords don't match");
            return;
            case 2:
                LblError.setText("Your password must be at least 8 characters long");
            return;
            case 3:
                LblError.setText("Your password must have letters, numbers, and special characters");
            return;
            default:
            break;
        }

        TxtName.setText("");
        TxtEmail.setText("");
        TxtPassword1.setText("");
        TxtPassword2.setText("");

        User Usr = new User();
        Usr.setName(Name);
        Usr.setEmail(Email);
        Usr.setPassword(Password1);

        Context Ctx = new Context();
        Ctx.Begin();
        Ctx.Save(Usr);
        Ctx.Commit();

        LblError.setText("User registered successfully");
    }

    @FXML
    public void Return() throws Exception
    {
        Stage Window = (Stage)Box.getScene().getWindow();
        Window.setScene(LoginController.CreateScene());
    }
}