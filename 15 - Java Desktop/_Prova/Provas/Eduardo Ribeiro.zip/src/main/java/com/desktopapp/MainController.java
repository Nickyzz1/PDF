package com.desktopapp;

import java.net.URL;
import java.util.*;

import com.desktopapp.model.User;
import com.desktopapp.model.Message;

import jakarta.persistence.TypedQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainController implements Initializable
{
    protected User Usr = new User();
    public static Scene CreateScene(User user) throws Exception
    {
        URL SceneUrl = MainController.class.getResource("MainWindow.fxml");
        FXMLLoader Loader = new FXMLLoader(SceneUrl);
        Parent Root = Loader.load();
        MainController Controller = Loader.getController();

        Controller.Usr.setId(user.getId());
        Controller.Usr.setName(user.getName());
        Controller.Usr.setEmail(user.getEmail());
        Controller.Usr.setPassword(user.getPassword());
        Controller.LblUser.setText("Olá, " + user.getName());
        Controller.LoadData();

        Scene Scene = new Scene(Root);
        return Scene;
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1)
    {
        LoadData();
    }

    @FXML
    public void LoadData()
    {
        ObservableList<TableColumn<Message, ?>> Columns = Table.getColumns();
        Columns.get(0).setCellValueFactory(new PropertyValueFactory<>("sender"));
        Columns.get(1).setCellValueFactory(new PropertyValueFactory<>("title"));

        Context Ctx = new Context();
        TypedQuery<Message> Query = Ctx.CreateQuery(Message.class, "SELECT m FROM Message m where dest = :dest");
        Query.setParameter("dest", Usr.getEmail());
        List<Message> Results = Query.getResultList();
        Ctx.Close();
        Table.setItems(FXCollections.observableList(Results));
    }

    @FXML
    protected Label LblUser;
    @FXML
    protected VBox Box;
    @FXML
    protected TableView<Message> Table;

    @SuppressWarnings("unchecked")
    @FXML
    public void ClickTable() throws Exception
    {
        TablePosition<Message, ?> Cell = (TablePosition<Message, ?>)Table.getSelectionModel().getSelectedCells().get(0);
        Message Msg = Table.getItems().get(Cell.getRow());

        Stage Stage = (Stage)Box.getScene().getWindow();
        Stage.close();

        Stage = new Stage();
        Stage.setScene(MsgController.CreateScene(Usr, Msg));
        Stage.show();
    }
    
    @FXML
    public void Logout() throws Exception
    {
        Stage Window = (Stage)Box.getScene().getWindow();
        Window.setScene(LoginController.CreateScene());
    }
}