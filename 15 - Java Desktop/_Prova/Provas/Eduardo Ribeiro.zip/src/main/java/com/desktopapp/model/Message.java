package com.desktopapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbMessage")
public class Message
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String sender, dest;
    private String title, message;

    public String getDest(){return dest;}
    public void setDest(String dest){this.dest = dest;}
    
    public String getSender(){return sender;}
    public void setSender(String sender){this.sender = sender;}

    public Long getId(){return id;}
    public void setId(Long id){this.id = id;}

    public String getMessage(){return message;}
    public void setMessage(String message){this.message = message;}

    public String getTitle(){return title;}
    public void setTitle(String title){this.title = title;}
}