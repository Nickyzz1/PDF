package com.desktopapp;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.desktopapp.model.User;

import jakarta.persistence.TypedQuery;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginController implements Initializable
{
    public static Scene CreateScene() throws Exception
    {
        URL SceneUrl = LoginController.class.getResource("LoginWindow.fxml");
        FXMLLoader Loader = new FXMLLoader(SceneUrl);
        Parent Root = Loader.load();
        Scene Scene = new Scene(Root);
        return Scene;
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1)
    {

    }

    @FXML
    protected VBox Box;

    @FXML
    protected TextField TxtName;
    @FXML
    protected PasswordField TxtPassword;
    @FXML
    protected Button BtnLogin;
    @FXML
    protected Button BtnRegister;
    @FXML
    protected Label LblError;
    
    @FXML
    public void Login() throws Exception
    {
        String Name = TxtName.getText(), Password = TxtPassword.getText();

        if(Name.contentEquals("") || Password.contentEquals(""))
        {
            LblError.setText("User data is incomplete");
            return;
        }

        Context Ctx = new Context();
        TypedQuery<User> Query = Ctx.CreateQuery
        (
            User.class,
            "Select u From User u Where (name = :name Or email = :name) And password = :password"
        );
        Query.setParameter("name", Name);
        Query.setParameter("password", Password);
        List<User> Results = Query.getResultList();
        Ctx.Close();
        if(Results.size() == 0)
        {
            Query = Ctx.CreateQuery
            (
                User.class,
                "Select u From User u Where (name = :name Or email = :name)"
            );
            Query.setParameter("name", Name);
            
            if(Query.getResultList().size() > 0)
            {
                LblError.setText("Wrong password");
            }else
            {
                LblError.setText("Wrong user");
            }
            Ctx.Close();
            return;
        }else
        {
            Stage Window = (Stage)Box.getScene().getWindow();
            Window.setScene(MainController.CreateScene(Results.get(0)));
        }
    }

    @FXML
    public void Register() throws Exception
    {
        Stage Window = (Stage)Box.getScene().getWindow();
        Window.setScene(RegisterController.CreateScene());
    }
}