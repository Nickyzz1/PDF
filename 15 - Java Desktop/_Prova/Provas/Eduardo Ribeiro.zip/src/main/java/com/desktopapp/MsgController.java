package com.desktopapp;

import java.net.URL;
import java.util.*;

import com.desktopapp.model.User;
import com.desktopapp.model.Message;

import jakarta.persistence.TypedQuery;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MsgController implements Initializable
{
    protected User Usr = new User();
    protected Message Msg = new Message();

    public static Scene CreateScene(User user, Message message) throws Exception
    {
        URL SceneUrl = MsgController.class.getResource("MsgWindow.fxml");
        FXMLLoader Loader = new FXMLLoader(SceneUrl);
        Parent Root = Loader.load();
        MsgController Controller = Loader.getController();

        Controller.Usr.setId(user.getId());
        Controller.Usr.setName(user.getName());
        Controller.Usr.setEmail(user.getEmail());
        Controller.Usr.setPassword(user.getPassword());

        Controller.Msg.setDest(message.getDest());
        Controller.Msg.setSender(message.getSender());
        Controller.Msg.setTitle(message.getTitle());
        Controller.Msg.setId(message.getId());
        Controller.Msg.setMessage(message.getMessage());

        Scene Scene = new Scene(Root);
        return Scene;
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1)
    {
        LoadData();
    }

    @FXML
    public void LoadData()
    {
        Context Ctx = new Context();
        TypedQuery<Message> Query = Ctx.CreateQuery(Message.class, "SELECT m FROM Message m where id = :id");
        Query.setParameter("id", Msg.getId());
        List<Message> Results = Query.getResultList();
        Ctx.Close();
    }

    @FXML
    protected VBox Box;

    @FXML
    public void Return() throws Exception
    {
        Stage Stage = (Stage)Box.getScene().getWindow();
        Stage.close();

        Stage = new Stage();
        Stage.setScene(MainController.CreateScene(Usr));
        Stage.show();
    }
}