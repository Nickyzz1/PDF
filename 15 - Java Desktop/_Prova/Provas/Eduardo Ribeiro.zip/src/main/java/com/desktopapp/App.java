package com.desktopapp;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application
{
    public static void main(String[] args)
    {
        User Usr = new User();
        Usr.setName("1");
        Usr.setEmail("1@1.1");
        Usr.setPassword("1.aaaaaa");

        User Usr2 = new User();
        Usr2.setName("2");
        Usr2.setEmail("2@2.2");
        Usr2.setPassword("2.aaaaaa");

        Context Ctx = new Context();
        Ctx.Begin();
        Ctx.Save(Usr);
        Ctx.Save(Usr2);
        Ctx.Commit();

        for(int i = 0; i < 5; ++i)
        {
            Message Msg = new Message();
            Msg.setDest(Usr.getEmail());
            Msg.setSender(Usr2.getEmail());
            Msg.setTitle(String.format("%d", i));
            Msg.setMessage("Bom dia 00000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
            Ctx.Begin();
            Ctx.Save(Msg);
            Ctx.Commit();
        }
        for(int i = 0; i < 5; ++i)
        {
            Message Msg = new Message();
            Msg.setDest(Usr2.getEmail());
            Msg.setSender(Usr.getEmail());
            Msg.setTitle(String.format("%d", 5+i));
            Msg.setMessage("Bom dia 00000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
            Ctx.Begin();
            Ctx.Save(Msg);
            Ctx.Commit();
        }

        launch(args);
    }

    @Override
    public void start(Stage arg0) throws Exception
    {
        Scene scene = LoginController.CreateScene();
        arg0.setScene(scene);
        arg0.show();
    }
}