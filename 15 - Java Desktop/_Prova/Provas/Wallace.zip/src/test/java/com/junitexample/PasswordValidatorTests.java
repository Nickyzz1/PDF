package com.junitexample;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.desktopapp.MyRegisterValidator;

public class PasswordValidatorTests {

    @Test
    void validateSmallPass() {
        assertEquals(MyRegisterValidator.Validate("testesenha", "hello", "sl", "testesenha"),false);
    }

    @Test
    void validate2() {
        assertEquals(MyRegisterValidator.Validate("testesenha", "hello", "sla@sdsa", "testesenha"),false);
    }

    @Test
    void validate3() {
        assertEquals(MyRegisterValidator.Validate("vaila", "hello", "sla@sdsa", "vaila"),false);
    }

    @Test
    void validate4() {
        assertEquals(MyRegisterValidator.Validate("jesuspaiamado", "hello", "sl", "jesuspaiamadinho"),false);
    }

}