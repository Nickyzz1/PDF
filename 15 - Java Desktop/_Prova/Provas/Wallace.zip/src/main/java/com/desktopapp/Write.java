package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class Write {

    Long id;

        public static Scene CreateScene(Long id) throws Exception {
        URL sceneUrl = Write.class.getResource("Write.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        var controller = (Write)loader.getController();
        controller.id = id;

        return scene;

    }

    @FXML
    protected TextArea email;

    @FXML
    protected TextArea titulo;

    @FXML
    protected TextArea texto;

    @FXML
    protected Button back;

    @FXML
    protected Button send;

    @FXML
    public void voltar(MouseEvent e) throws Exception{
            Stage crrStage = (Stage) back.getScene().getWindow();
            crrStage.close();
    }

    @FXML
    public void enviar(MouseEvent e){
        Message mensagem = new Message();

        Context ctx = new Context();
        var user = ctx.find(User.class, "SELECT u FROM User u WHERE u.email = :arg0",
                email.getText());

        var sender = ctx.find(User.class, "SELECT u FROM User u WHERE u.id = :arg0",
               id);

        mensagem.setUserSender(sender.get(0).getName());
        mensagem.setidUser2(user.get(0).getId());
        mensagem.setTitle(titulo.getText());
        mensagem.setMessage(texto.getText());

        ctx.begin();
        ctx.save(mensagem);
        ctx.commit();

        Stage crrStage = (Stage) back.getScene().getWindow();
        crrStage.close();
    }
}
