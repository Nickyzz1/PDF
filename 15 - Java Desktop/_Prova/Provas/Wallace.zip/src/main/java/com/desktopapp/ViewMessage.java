package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Message;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;

public class ViewMessage {
        public static Scene CreateScene(Message mensagem) throws Exception {
        URL sceneUrl = ViewMessage.class.getResource("ViewMessage.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        var controller = (ViewMessage)loader.getController();
        controller.mensagemzona.setText(mensagem.getMessage());;
        controller.tituloo.setText(mensagem.getTitle());

        return scene;

    }

    @FXML
    protected Label tituloo;

    
    @FXML
    protected Label mensagemzona;
}
