package com.desktopapp.model;

import jakarta.persistence.Id;
import jakarta.persistence.Table;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Entity
@Table(name = "tbMessage")
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    private String UserSender;

    public String getUserSender() {
        return UserSender;
    }

    public void setUserSender(String UserSender) {
        this.UserSender = UserSender;
    }

    
    private Long idUser2;

    public Long getidUser2() {
        return idUser2;
    }

    public void setidUser2(Long idUser2) {
        this.idUser2 = idUser2;
    }


    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
