package com.desktopapp;

import com.desktopapp.model.User;

public class MyRegisterValidator {
    
    public static boolean Validate(String password, String name, String email, String confirmPassword) {

        Context ctx = new Context();
        var namebd = ctx.find(User.class, "SELECT u FROM User u WHERE u.name = :arg0",
                name);

        var emailbd = ctx.find(User.class, "SELECT u FROM User u WHERE u.name = :arg0",
            email);

        if (password.length() >= 8){
            if (confirmPassword == password) {
                if (namebd.size() == 0) {
                    if (email.contains("@")) {
                        if (emailbd.size() == 0) {
                            return true;
                        }
                    
                    }
                }
            }   
        }     
        return password.chars()
            .anyMatch(c -> c >= '0' && c <= '9');
    }
}
