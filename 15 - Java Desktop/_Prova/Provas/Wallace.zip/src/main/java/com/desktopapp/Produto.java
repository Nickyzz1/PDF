// package com.desktopapp;


// import java.net.URL;

// import com.desktopapp.model.Product;

// import javafx.fxml.FXML;
// import javafx.fxml.FXMLLoader;
// import javafx.scene.Parent;
// import javafx.scene.Scene;
// import javafx.scene.control.Button;
// import javafx.scene.control.TextField;
// import javafx.scene.input.MouseEvent;
// import javafx.stage.Stage;

// public class Produto {
    


//     public static Scene CreateScene() throws Exception {
//         URL sceneUrl = Produto.class.getResource("Product.fxml");
//         FXMLLoader loader = new FXMLLoader(sceneUrl);
//         Parent root = loader.load();
//         Scene scene = new Scene(root);

//         return scene;
//     }

//     @FXML
//     protected Button Insert;

//     @FXML
//     protected TextField product;

//     @FXML
//     protected TextField price;

//     @FXML
//     protected TextField description;

//     @FXML
//     public void createProduct(MouseEvent e)throws Exception{


//         Product produto = new Product();
//         produto.setProduct(product.getText());
//         produto.setPrice(price.getText());
//         produto.setDescription(description.getText());

//         Context ctx = new Context();
//         ctx.begin();
//         ctx.save(produto);
//         ctx.commit();


//         Stage crrStage = (Stage) Insert.getScene().getWindow();
//         crrStage.close();
//         // Abrindo a tela principal
//         Stage stage = new Stage();
//         Scene scene = Tabela.CreateScene();
//         stage.setScene(scene);
//         stage.show();

//     }

// }
