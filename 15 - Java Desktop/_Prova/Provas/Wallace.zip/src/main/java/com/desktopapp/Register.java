package com.desktopapp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.net.URL;

import com.desktopapp.model.User;

public class Register {



    public static Scene CreateScene() throws Exception {
        URL sceneUrl = Register.class.getResource("Register.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        return scene;
    }

    @FXML
    protected Button button;

    @FXML
    protected TextArea usuario;

    @FXML
    protected TextArea email;

    @FXML
    protected PasswordField senha1;

    
    @FXML
    protected PasswordField senha2;

    @FXML
    public void onRegisterCreated(MouseEvent e) throws Exception {
        User user = new User();


        if (MyRegisterValidator.Validate(senha1.getText(), usuario.getText(), email.getText(), senha2.getText())) {
            
            user.setName(usuario.getText());
            user.setEmail(email.getText());
            user.setPassword(senha1.getText());
            Context ctx = new Context();
            ctx.begin();
            ctx.save(user);
            ctx.commit();
    
            Stage crrStage = (Stage) button.getScene().getWindow();
            crrStage.close();
            // Abrindo a tela principal
            Stage stage = new Stage();
            Scene scene = MainController.CreateScene();
            stage.setScene(scene);
            stage.show();
        }
        else{
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "Senha incorreta!",
                    ButtonType.OK);
            alert.showAndWait();
         }
    }











}
