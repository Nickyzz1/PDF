package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.User;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.control.ButtonType;

public class MainController {



    public static Scene CreateScene() throws Exception {
        URL sceneUrl = MainController.class.getResource("Login.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);



        return scene;

    }

    @FXML
    protected Button button;

    @FXML
    protected TextArea usuario;

    @FXML
    protected PasswordField senha;



    @FXML
    protected CheckBox check;

    @FXML
    protected void onButtonClicked(MouseEvent e) throws Exception {

        Context ctx = new Context();
        var user = ctx.find(User.class, "SELECT u FROM User u WHERE u.name = :arg0",
                usuario.getText());

        var email = ctx.find(User.class, "SELECT u FROM User u WHERE u.email = :arg0",
            usuario.getText());

        if (user.size() == 0 && email.size() == 0 ) {
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "Usuário não está cadastrado!",
                    ButtonType.OK);
            alert.showAndWait();
            return;
        }
        
        
        var senhaUser = user.size() > 0 ? user.get(0) : email.get(0);
        System.err.println(senhaUser.getPassword());
        if (!senha.getText().equals(senhaUser.getPassword())) {
            Alert alert = new Alert(
                    AlertType.ERROR,
                    "Senha incorreta!",
                    ButtonType.OK);
            alert.showAndWait();
            return;
        }


        // Fechando o login
        Stage crrStage = (Stage) button.getScene().getWindow();

        Scene scene = Messages.CreateScene(senhaUser.getId());
        crrStage.setScene(scene);
        crrStage.show();
    }

    @FXML
    public void OnRegisterClicked(MouseEvent e) throws Exception {

        Stage crrStage = (Stage) button.getScene().getWindow();
        crrStage.close();
        // Abrindo a tela principal
        Stage stage = new Stage();
        Scene scene = Register.CreateScene();
        stage.setScene(scene);
        stage.show();

    }

}
