package com.desktopapp;

import com.desktopapp.model.User;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class App extends Application {

    @Override
    public void start(Stage primarStage) throws Exception {
        Scene scene = MainController.CreateScene();
        primarStage.setScene(scene);
        primarStage.show();
    }

    public static void main(String[] args) {


        Context ctx = new Context();
        var admin = ctx.find(User.class, "SELECT u FROM User u WHERE u.name = :arg0",
                "admin");

                if (admin.size() == 0) {
                    User user = new User();
                    user.setName("admin");
                    user.setEmail("admin@admin");
                    user.setPassword("admin");
                    ctx.begin();
                    ctx.save(user);
                    ctx.commit();
                }


        launch(args);
    }

}