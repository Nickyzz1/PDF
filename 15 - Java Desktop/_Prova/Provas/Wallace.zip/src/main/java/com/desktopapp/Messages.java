package com.desktopapp;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;


import javafx.scene.control.TableCell;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


public class Messages implements Initializable {

     Long id;

        public static Scene CreateScene(Long id) throws Exception {
        URL sceneUrl = Messages.class.getResource("Messages.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        Context ctx = new Context();
        var user = ctx.find(User.class, "SELECT u FROM User u WHERE u.id = :arg0",id);
        
        var controller = (Messages)loader.getController();
        controller.id = id;
        controller.nameUser.setText(user.get(0).getName());

        // System.out.println(id);

        return scene;

    }


    @FXML
    protected Button logout;

    @FXML
    protected Button write;

    @FXML
    protected Label nameUser;

    @FXML
    protected TableView<Message> tableMessages;
    
    @FXML
    protected TableColumn<Message, String> Sender;

    @FXML
    protected TableColumn<Message, String> titulo;

    @FXML
    public void sair(MouseEvent e) throws Exception{
        Stage crrStage = (Stage) logout.getScene().getWindow();
        Scene scene = MainController.CreateScene();
        crrStage.setScene(scene);
        crrStage.show();
    }

    @FXML
    public void escrever(MouseEvent e) throws Exception{

        Stage stage = new Stage();
        Scene scene = Write.CreateScene(id);
        stage.setScene(scene);
        stage.show();
        
    }
    Timer timer = new Timer();
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        Context ctx = new Context();
        



        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                var messages = ctx.createQuery(Message.class, "SELECT u FROM Message u WHERE u.idUser2 = :id");
                System.out.println(id);
                messages.setParameter("id", id);
                // System.out.println(messages.getResultList());
                ObservableList<Message> obsTeste = FXCollections.observableArrayList(messages.getResultList());
                System.out.println(id);
                Sender.setCellValueFactory(
                        new PropertyValueFactory<>("UserSender"));
                titulo.setCellValueFactory(
                    new PropertyValueFactory<>("title"));
                
                // titulo.setCellFactory(col -> new TableCell<Message, String>() {    
                    
                //     @Override
                //     protected void updateItem(String item, boolean empty) {
                //         super.updateItem(item, empty);
                //         if (empty) {
                //             setGraphic(null);
                //         } else {
                //             // setOnMouseClicked(abrirpagina(null));
                //         }
                //     }

                // });

                
                tableMessages.setItems(obsTeste);
            }
        }, 5000, 5000);
    }

    public void abrirpagina(MouseEvent e){}
    
}