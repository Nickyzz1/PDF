package com.desktopapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.beans.Transient;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

public class PasswordValidatorTests {


    @Test
    void validatePassword() {
        assertEquals(MyPasswordValidator.Validate("senha123"), true);
        assertEquals(MyPasswordValidator.Validate("12345"), false);
        assertEquals(MyPasswordValidator.Validate("123456789012"), true);
        assertEquals(MyPasswordValidator.Validate("oi88oi88oi88"), true);
    }

    @Test
    void ValidateEmail() {
        ArrayList<String> empty = new ArrayList<>();
        assertEquals(MyPasswordValidator.ValidateEmail("email@exemplo.com", "senha1234", "senha1234"), empty );
    }
}