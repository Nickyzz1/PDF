package com.desktopapp;

// import org.hibernate.mapping.List;
import java.util.*;


import com.desktopapp.model.User;

public class MyPasswordValidator {
    
    public static boolean Validate(String password) {

        // senha menor que 8 
        if (password.length() < 8)
            return false;

        // verifica se tem números
        return password.chars()
            .anyMatch(c -> c >= '0' && c <= '9');

    }

    public static ArrayList<String> validateuou(){
        ArrayList<String> list = new ArrayList<>();
        list.add("oi");
        return list;
    }

    public static ArrayList<String> ValidateEmail(String email, String password, String password1) {

        ArrayList<String> list = new ArrayList<>();

        if (!password.equals(password1)) {
            var err = "The confirmed password does not match.";
            list.add(err);
        }

        // senha menor que 8 
        if (password.length() < 8) {
            var err = "Password must have at least 8 characters";
            list.add(err);
        }
           
        // verifica se tem números
        if (!password.chars().anyMatch(c -> c >= '0' && c <= '9')) {
            var err = "Password must have numbers in it.";
            list.add(err);
        }

        Context ctx = new Context();
        var query = ctx.createQuery(User.class, "from User u where u.email = :email");
        query.setParameter("email", email);

        // pega todos os usuários, faz um map com eles e torna-os os próprios e-mails
        List<String> users = query.getResultList().stream().map( user -> user.getEmail()).toList();
        
        // verifica se o e-mail já existe no banco. como um usuário pode ter o mesmo nome que outro, não eralizei a verificação mas seguiria a mesma lógica :)
        if (users.contains(email)) {

            var err = "Email already registered in our database.";
            list.add(err);
        } 
        
        email = email.concat(" ");

        // se não tiver '@' já para por aqui
        if (!email.contains("@")) {
            var err = "Email must be in the format: 'something@something.somthing'. You forgot the '@'";
            list.add(err);
        } else {

            var emailRest = email.split( "@");
            // list.add(emailRest[0]);
            // list.add(emailRest[1]);
            
            // se não tiver '.' já para por aqui
            if (!emailRest[1].contains("\\.")) {
                // sempre retorna falsa ainda que tenha o ponto 
                // var err = "Email must be in the format: 'something@something.somthing'. You forgot the '.'";
                // list.add(err);
            } else {
    
                emailRest[1] = emailRest[1].concat(" ");
        
                var emailRestRest = emailRest[1].split( "\\.");
            
                // verifica se após o ponto existe algo escrito, como "com" ou "br" ou alguma outra coisa
                if (emailRestRest[1].length() <= 0) {
                    var err = "Email must be in the format: 'something@something.somthing'. You forgot to write after the '.'";
                    list.add(err);
                }
            }
        }
        
            
        return list;
            
    }
}
