package com.desktopapp;

import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import com.desktopapp.model.User;

import jakarta.persistence.EntityManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class EditAccountController {

    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @FXML
    protected Button registerButton;

    @FXML
    protected Button goBack;

    @FXML
    protected TextField passwordInput;
    
    @FXML
    protected TextField passwordInput1;

    @FXML
    protected TextField emailInput;

    @FXML
    protected TextField nameInput;

    @FXML
    protected Text errorsText;

    public static Scene CreateScene(User user) throws Exception {

        URL sceneUrl = EditAccountController.class.getResource("EditAccount.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        EditAccountController controller = loader.getController();
        controller.setUser(user);

        controller.nameInput.setText(user.getName());
        controller.emailInput.setText(user.getEmail());
        controller.passwordInput.setText(user.getPassword());

        return scene;
    }

    public void register(MouseEvent e) throws Exception {

        String message = "An error occured, try again.";

        var email = this.emailInput.getText();
        var name = this.nameInput.getText();
        var ps = this.passwordInput.getText();
        var ps1 = this.passwordInput1.getText();

        ArrayList<String> err = MyPasswordValidator.ValidateEmail(email, ps, ps1);

        errorsText.setText("");

        for (String string : err) {
            System.out.println(string);
        }

        if (err.size() > 0) {
            errorsText.setVisible(true);


            for (String string : err) {
                errorsText.setText(errorsText.getText() + string + "\n");
                
            }

        } else {

            errorsText.setVisible(false);
            

            Context ctx = new Context();

            User user = new User();
            user.setName(this.nameInput.getText());
            user.setPassword(this.passwordInput.getText());
            user.setEmail(this.emailInput.getText());
    
            EntityManager em = ctx.creaEntityManager();
    
            try {
                em.getTransaction().begin();
                ctx.begin();
                ctx.update(user);
                ctx.commit();
                message = "New empolyee inserted succesfully! 😊";
    
            } catch (Exception ex) {
                if (em.getTransaction().isActive()) {
                    em.getTransaction().rollback();
                }
    
                ex.printStackTrace();
                em = null;
    
            } finally {
                em.close();
            }
    
            Scene warningScene = AlertController.CreateScene(message);
    
            Stage newStage = new Stage();
            newStage.setScene(warningScene);
            newStage.show();
        }
    
    }

    @FXML
    protected void goBack(MouseEvent e) throws      Exception {
        Stage crrStage = (Stage) registerButton.getScene().getWindow();
        crrStage.close();
        
        Scene nextScene = LoginController.CreateScene();

        Stage nextStage = new Stage();
        nextStage.setScene(nextScene);
        nextStage.show();

    }

}
