package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class WriteMessageController {

    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @FXML
    protected Text autocomplete;

    @FXML
    protected Button registerButton;

    @FXML
    protected Button goBack;

    @FXML
    protected TextField titleInput;

    @FXML
    protected TextField emailInput;

    @FXML
    protected TextArea messageInput;

    public static Scene CreateScene(User user) throws Exception {

        URL sceneUrl = WriteMessageController.class.getResource("WriteMessage.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        WriteMessageController controller = loader.getController();
        controller.setUser(user);

        System.out.println("\n\n\nUSER INFO: ");
        System.out.println(controller.getUser().getEmail());
        System.out.println(controller.getUser().getName());
        System.out.println(controller.getUser().getPassword());

        controller.emailInput.textProperty().addListener((observable, oldValue, newValue) -> {
            Context newContext = new Context();

            User userFound = newContext.find(User.class, "select u from User u where email LIKE :arg0", "%" + controller.emailInput.getText() + "%").getFirst();

            if (userFound != null)
                controller.autocomplete.setText(userFound.getEmail());
                controller.autocomplete.setVisible(true);
        });


        return scene;
    }

    public void autocomplete(MouseEvent e) throws Exception {
        this.emailInput.setText(autocomplete.getText());

    }

    public void register(MouseEvent e) throws Exception {

        String message = "An error occured, try again.";

        Context ctx = new Context();

        Message newMessage = new Message();
        newMessage.setMessage(this.messageInput.getText());
        newMessage.setReciever((this.emailInput.getText()));
        newMessage.setTitle((this.titleInput.getText()));
        newMessage.setSender((this.getUser().getEmail()));

        System.out.println("\n\n\n\nINFO:");
        System.out.println(newMessage.getMessage());
        System.out.println(newMessage.getReciever());
        System.out.println(newMessage.getSender());
        System.out.println(newMessage.getTitle());
        // EntityManager em = ctx.creaEntityManager();

        // try {
            // em.getTransaction().begin();
            ctx.begin();
            ctx.save(newMessage);
            ctx.commit();
            message = "Message sent successfully 😊";

        // } catch (Exception ex) {
        //     if (em.getTransaction().isActive()) {
        //         em.getTransaction().rollback();
        //     }

        //     ex.printStackTrace();
        //     em = null;

        // } finally {
        //     em.close();
        // }

        Scene warningScene = AlertController.CreateScene(message);

        Stage newStage = new Stage();
        newStage.setScene(warningScene);
        newStage.show();

    }

    @FXML
    protected void goBack(MouseEvent e) throws Exception {
        Stage crrStage = (Stage) registerButton.getScene().getWindow();
        crrStage.close();
        
        Scene nextScene = InboxController.CreateScene(getUser());

        Stage nextStage = new Stage();
        nextStage.setScene(nextScene);
        nextStage.show();

    }

}
