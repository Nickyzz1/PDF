package com.desktopapp;

import java.net.URL;

import java.util.*;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ShowMessageController {

    private Message message;

    public void setUser(Message message) {
        this.message = message;
    }

    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @FXML
    protected Text titleText;

    @FXML
    protected Text senderText;

    @FXML
    protected Text firstLetter;

    @FXML
    protected Text messageText;

    @FXML
    protected Button logOutButton;

    @FXML
    protected Button inboxButton;

    public static Scene CreateScene(Message message, User user) throws Exception {
        URL sceneUrl = ShowMessageController.class.getResource("ShowMessage.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        ShowMessageController controller = loader.getController();

        controller.senderText.setText(message.getSender());
        controller.messageText.setText(message.getMessage());
        controller.titleText.setText(message.getTitle());

        controller.firstLetter.setText(user.getEmail().substring(0, 1).toUpperCase());

        controller.setUser(user);
        
        return scene;
    }

    public void onButtonClick(MouseEvent e) throws Exception {

        var confirm = InteractionWarningController.ShowAndWait(
            "Are you sure you want to log out?"
        );

        if (confirm)
        {
            Stage crrStage = (Stage) logOutButton.getScene().getWindow();
            crrStage.close();

            Scene loginScene = LoginController.CreateScene();
            Stage newStage = new Stage();
            newStage.setScene(loginScene);
            newStage.show();
        }
    }
    @FXML
    protected void goToInbox(MouseEvent e) throws Exception {

        Stage crrStage = (Stage) logOutButton.getScene().getWindow();
        crrStage.close();
        
        Scene nextScene = InboxController.CreateScene(getUser());
        Stage nextStage = new Stage();
        
        nextStage.setScene(nextScene);
        nextStage.show();

    }

}
