package com.desktopapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class PasswordValidatorTests {

    @Test
    void validateSmallPass() {
        assertEquals(MyPasswordValidator.ValidatePass("oi"), false);
        assertEquals(MyPasswordValidator.ValidatePass("1234"), false);
        assertEquals(MyPasswordValidator.ValidatePass("oioi"), false);
        assertEquals(MyPasswordValidator.ValidatePass("minh"), false);
    }

    @Test
    void validateBigPasswords() {
        assertEquals(MyPasswordValidator.ValidatePass("minhasenha12&3"), true);
        assertEquals(MyPasswordValidator.ValidatePass("1234567890123@"), false);
        assertEquals(MyPasswordValidator.ValidatePass("minhasenhagigantesc@1"), true);
        assertEquals(MyPasswordValidator.ValidatePass("senhaemoji 👻"), false);
    }

    @Test
    void validateMediumPasswordsWithNums() {
        assertEquals(MyPasswordValidator.ValidatePass("senha123"), false);
        assertEquals(MyPasswordValidator.ValidatePass("12345"), false);
        assertEquals(MyPasswordValidator.ValidatePass("12345678901a@2"), true);
        assertEquals(MyPasswordValidator.ValidatePass("oi88oi88oi88@ç"), true);
    }

    @Test
    void validateMediumPassowrdsWithoutNums() {
        assertEquals(MyPasswordValidator.ValidatePass("minhasenha"), false);
        assertEquals(MyPasswordValidator.ValidatePass("mysenhaquase"), false);
    }
}