package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegisterSceneController {
    public static Scene CreateScene() throws Exception {
        URL sceneUrl = LoginSceneController.class
            .getResource("register-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }

    @FXML
    protected Button btnRegister;

    @FXML
    protected Button btnBack;

    @FXML
    protected TextField tfName;

    @FXML
    protected TextField tfEmail;

    @FXML
    protected PasswordField pfPass;

    @FXML
    protected PasswordField pfRepetePass;

    @FXML
    protected void Register(ActionEvent e) throws Exception {
        Context ctx = new Context();

        var textName = tfName.getText();
        var textEmail = tfEmail.getText();
        var textPass = pfPass.getText();
        var textRepeatPass = pfRepetePass.getText();

        if (!ctx.check(textName, textPass)) {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Já existe um usuário com esse nome ou email!",
                ButtonType.OK
            );

            alert.showAndWait();
            return;
        }

        if (!textEmail.contains("@")) {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Insira um email válido!",
                ButtonType.OK
            );

            alert.showAndWait();
            return;
        }

        if (!textPass.equals(textRepeatPass)) {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Ambos os campos de senha precisam estar iguais!",
                ButtonType.OK
            );

            alert.showAndWait();
            return;
        }

        User user = new User();
        user.insertUser(textName, textEmail, textPass);
        ctx.begin();
        ctx.save(user);
        ctx.commit();

        var crrStage = (Stage)btnBack
            .getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = LoginSceneController.CreateScene();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void Back(ActionEvent e) throws Exception {
        var crrStage = (Stage)btnBack
                .getScene().getWindow();
            crrStage.close();

            var stage = new Stage();
            var scene = LoginSceneController.CreateScene();
            stage.setScene(scene);
            stage.show();
    }

}
