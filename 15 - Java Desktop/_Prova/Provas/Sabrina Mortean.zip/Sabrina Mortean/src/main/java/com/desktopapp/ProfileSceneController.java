package com.desktopapp;

import java.net.URL;
import java.util.ResourceBundle;

import com.desktopapp.model.User;

import jakarta.persistence.TypedQuery;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ProfileSceneController implements Initializable{
    static String nomeLindo;


    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        insertData();
    }

    public static Scene CreateScene(String name) throws Exception {
        nomeLindo = name;
        // System.out.println("\n\n\n\n\n\n\n\n\nNome: " + name);
        URL sceneUrl = ProfileSceneController.class
            .getResource("profile-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }



    @FXML
    protected Button btnBack;
    
    @FXML
    protected TextField tfName;

    @FXML
    protected TextField tfEmail;

    @FXML
    protected TextField tfPass;

    @FXML
    protected Button btnModify;



    @FXML
    protected void BackMain(ActionEvent e) throws Exception {
        var crrStage = (Stage)btnBack
            .getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = MainSceneController.CreateScene(nomeLindo);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void Apagar(ActionEvent e) throws Exception {
            Alert alert = new Alert(
                AlertType.CONFIRMATION,
                "Função em desenvolvimento!",
                ButtonType.OK
            );

            alert.showAndWait();
            return;
        // Context ctx = new Context();
        // ctx.begin();

        // ctx.deleteEntity(User.class, );
    }

    @FXML
    protected void Modify(ActionEvent e) throws Exception {
        Alert alert = new Alert(
            AlertType.CONFIRMATION,
            "Função em desenvolvimento!",
            ButtonType.OK
        );

        alert.showAndWait();
        return;

        // Seria algo assim

        // TypedQuery<User> query = ctx.createQuery(User.class, "UPDATE FROM User u WHERE u.name = :name");
        // query.setParameter("name", nomeLindo);

        // var user = query.getResultList();
    }

    public void insertData() {
        Context ctx = new Context();
        ctx.begin();
        // TypedQuery<User> query = ctx.createQuery(User.class, "SELECT u FROM User u WHERE u.name = :name");
        // query.setParameter("name", nomeLindo);

        // var user = query.getResultList();

        // User usuario = new User();

    }


}
