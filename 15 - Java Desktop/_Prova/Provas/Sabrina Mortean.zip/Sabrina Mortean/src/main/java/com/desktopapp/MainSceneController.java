package com.desktopapp;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.desktopapp.model.Messages;

import jakarta.persistence.TypedQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

public class MainSceneController implements Initializable{
    @FXML
    protected Label HelloPerson;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // System.out.println("\n\n\n\n\n\n\n\nNome: " + nomeLindoPessoa);
        HelloPerson.setText("Olá, " + nomeLindoPessoa + "!");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("message"));

        addButtonToTable();
    
        tabela.setItems(exibirMensagens());
    }

    static String nomeLindoPessoa;

    public static Scene CreateScene(String name) throws Exception {
        nomeLindoPessoa = name;
        // System.out.println("\n\n\n\n\n\n\n\n\n\nNome: " + name);
        URL sceneUrl = MainSceneController.class
            .getResource("main-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }

    
    @FXML
    protected Button btnLogout;

    @FXML
    protected Button btnEmail;


    @FXML
    protected Button btnProfile;

    @FXML
    protected TableView<Messages> tabela;

    @FXML
    protected TableColumn<Messages, String> nameCol;

    @FXML
    protected TableColumn<Messages, String> emailCol;

    @FXML
    protected TableColumn<Messages, Void> checkCol;

    

    @FXML
    protected void Logout(ActionEvent e) throws Exception {
        var crrStage = (Stage)btnLogout
            .getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = LoginSceneController.CreateScene();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void SendEmail(ActionEvent e) throws Exception {
        var crrStage = (Stage)btnLogout
            .getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = EmailSceneController.CreateScene(nomeLindoPessoa);
        stage.setScene(scene);
        stage.show(); 
    }

    @FXML
    protected void Profile(ActionEvent e) throws Exception {
        var crrStage = (Stage)btnLogout
            .getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = ProfileSceneController.CreateScene(nomeLindoPessoa);
        stage.setScene(scene);
        stage.show();
    }
    
    public ObservableList<Messages> exibirMensagens() {
        Context ctx = new Context();

        ObservableList<Messages> lista = FXCollections.observableArrayList();

        try {
            String jpql = "SELECT m FROM Messages m";
            TypedQuery<Messages> query = ctx.createQuery(Messages.class, jpql);
            List<Messages> messageList = query.getResultList();

            lista.addAll(messageList);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }

    static String emailLindo;
    static String mensagemLinda;

    private void addButtonToTable() {
    Callback<TableColumn<Messages, Void>, TableCell<Messages, Void>> cellFactory = new Callback<TableColumn<Messages, Void>, TableCell<Messages, Void>>() {
        @Override
        public TableCell<Messages, Void> call(final TableColumn<Messages, Void> param) {
            final TableCell<Messages, Void> cell = new TableCell<Messages, Void>() {

                public final Button btn = new Button("Ver");

                {
                    btn.setOnAction((ActionEvent event) -> {
                        Messages mensagem = getTableView().getItems().get(getIndex());
                        System.out.println("\n\n\n\n\n\nEmail: " + mensagem.getEmail());
                        System.out.println("Mensagem: " + mensagem.getMessage());
                        System.out.println("\n\nNão deu tempo de colocar numa telinha bonita ;-;\n\n\n\n\n");

                        emailLindo = mensagem.getEmail();
                        mensagemLinda = mensagem.getMessage();
                        Alert alert = new Alert(
                            AlertType.CONFIRMATION,
                            "Olha no terminal",
                            ButtonType.OK
                        );

                        alert.showAndWait();
                        return;


                        // Eu não faço ideia do pq essa coisa não funciona, sorry

                        // var crrStage = (Stage)btn
                        //     .getScene().getWindow();
                        // crrStage.close();
                
                        // var stage = new Stage();
                        // var scene = MessageSceneController.CreateScene(emailLindo, mensagemLinda, nomeLindoPessoa);
                        // stage.setScene(scene);
                        // stage.show();
                    });
                }

                @Override
                public void updateItem(Void item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        setGraphic(btn);
                    }
                }
            };
            return cell;
        }
    };

        checkCol.setCellFactory(cellFactory);
    }

    // Eu tentei abrir com modal, mas a função não funcionava lá dentro do bgl

    // public void seeMessage(String email, String message) throws Exception {
    //     Dialog<Void> dialog = new Dialog<>();
    //     dialog.initModality(Modality.APPLICATION_MODAL);
    //     dialog.setTitle("Email de: " + email);

    //     Label label = new Label(message);

    //     VBox vbox = new VBox(label);
    //     dialog.getDialogPane().setContent(vbox);

    //     dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
    //     dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);

    //     dialog.showAndWait();
    // }

}
