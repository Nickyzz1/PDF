package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Messages;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EmailSceneController {
    public static Scene CreateScene(String name) throws Exception {
        nomeLindo = name;
        URL sceneUrl = LoginSceneController.class
            .getResource("email-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }

    static String nomeLindo;

    @FXML
    protected Button btnBack;

    @FXML
    protected Button btnSend;

    @FXML
    protected TextField tfEmail;

    @FXML
    protected TextArea taMessage;

    @FXML
    protected void Back(ActionEvent e) throws Exception {
        var crrStage = (Stage)btnBack
            .getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = MainSceneController.CreateScene(nomeLindo);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void Send(ActionEvent e) throws Exception {
        var textEmail = tfEmail.getText();
        var textMessage = taMessage.getText();

        Messages message = new Messages();

        Context ctx = new Context();
        if (ctx.checkEmail(textEmail)) {
            message.insertMessage(textEmail, textMessage);

            ctx.begin();
            ctx.save(message);
            ctx.commit();

            var crrStage = (Stage)btnBack
                .getScene().getWindow();
            crrStage.close();

            var stage = new Stage();
            var scene = MainSceneController.CreateScene(nomeLindo);
            stage.setScene(scene);
            stage.show();
        }

        else {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Usuário não encontrado!",
                ButtonType.OK
            );

            alert.showAndWait();
            return;
        }
        
    }
}
