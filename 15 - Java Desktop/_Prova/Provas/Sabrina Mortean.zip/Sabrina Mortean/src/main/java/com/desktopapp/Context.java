package com.desktopapp;

import java.util.List;

import com.desktopapp.model.User;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

public class Context {
    private EntityManagerFactory emf;
    private EntityManager em;

    public Context() {
        emf = Persistence.createEntityManagerFactory("my-persistence-unit");
    }

    public void begin() {
        em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
            em = null;
        }
    }

    public <T> T find(Class<T> entityClass, Object primaryKey) {
        EntityManager em = emf.createEntityManager();
        T user = null;
        try {
            user = em.find(entityClass, primaryKey);
        } finally {
            em.close();
        }
        return user;
    }

    public <T> TypedQuery<T> createQuery(Class<T> entityClass, String query) {
        EntityManager em = emf.createEntityManager();
        try {
            var queryObj = em.createQuery(query, entityClass);
            System.out.println("\n\n\n\n\nCriou a query na função");
            return queryObj;
        } catch (Exception e) {
            e.printStackTrace();
            em.close();
            em = null;
            System.out.println("\n\n\n\n\n\nCaiu no erro da função da query");
            return null;
        }
    }

     public <T> void deleteEntity(Class<T> entityClass, T entity) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = null;

        try {
            transaction = em.getTransaction();
            transaction.begin(); 

            if (!em.contains(entity)) {
                entity = em.merge(entity); 
            }

            em.remove(entity); 
            transaction.commit();
            System.out.println("\n\n\n\n\n\n\nEntidade deletada com sucesso!");
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback(); 
            }
            e.printStackTrace();
            System.out.println("\n\n\n\n\n\n\nErro ao deletar a entidade.");
        } finally {
            em.close(); 
        }
    }

    public <T> List<T> find(Class<T> entytyClass, String query, Object... values)
    {
        EntityManager em = emf.createEntityManager();
        List<T> users = null;
        try {
            var queryObj = em.createQuery(query, entytyClass);
            for (Integer i = 0; i < values.length; i++) {
                queryObj = queryObj.setParameter("arg" + i.toString(), values[i]);
            }
            users = queryObj.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            em.close();
            em = null;
        }
        return users;
    }

    public boolean checkUser(String name, String password) {
        

        if (name.contains("@")) {
            Context ctx = new Context();
            ctx.begin();
            TypedQuery<User> query = ctx.createQuery(User.class, "SELECT u FROM User u WHERE u.email = :email AND u.password = :password");
            query.setParameter("email", name);
            query.setParameter("password", password);
            var users = query.getResultList();

            if (users.size() == 1) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            Context ctx = new Context();
            ctx.begin();
            TypedQuery<User> query = ctx.createQuery(User.class, "SELECT u FROM User u WHERE u.name = :name AND u.password = :password");
            query.setParameter("name", name);
            query.setParameter("password", password);
            var users = query.getResultList();

            if (users.size() == 1) {
                return true;
            }
            else {
                return false;
            }
        }
    }

    public boolean check(String name, String email) {
        Context ctx = new Context();
        ctx.begin();
        TypedQuery<User> query = ctx.createQuery(User.class, "SELECT u FROM User u WHERE u.email = :email OR u.name = :name");
        query.setParameter("email", email);
        query.setParameter("name", name);
        var users = query.getResultList();
        
        if (users.size() == 1) {
            return false;
        }
        else {
            return true;
        }
        
    }

    public boolean checkEmail(String email) {
        Context ctx = new Context();
        ctx.begin();
        TypedQuery<User> query = ctx.createQuery(User.class, "SELECT u FROM User u WHERE u.email = :email");
        query.setParameter("email", email);
        var users = query.getResultList();
        
        if (users.size() == 1) {
            return true;
        }

        else {
            return false;
        }
    }

    public void save(Object object) {
        if (em == null) {
            System.out.println("connection is null.");
            return;
        }

        try {
            em.persist(object);
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
            em = null;
        }
    }

    public void commit() {
        if (em == null) {
            System.out.println("connection is null.");
            return;
        }

        try {
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            em = null;
        }
    }
}