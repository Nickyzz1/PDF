package com.desktopapp;

public class MyPasswordValidator {
    public static boolean ValidatePass(String pass) {

        pass = pass.toLowerCase();

        // Para ver se a senha é maior que 8 caracteres
        if (pass.length() < 8)
            return false;
        
        // Para ver se a senha tem caracteres especiais
        if (pass.contains("@") | pass.contains(".") | pass.contains("_") | pass.contains("#") | pass.contains("&"))
            return true;
        
        // Para ver se a senha tem letras
        if (pass.contains("a") | pass.contains("b") | pass.contains("c") | pass.contains("d") | pass.contains("e") | pass.contains("f") | pass.contains("g") | pass.contains("h") | pass.contains("i") | pass.contains("j") | pass.contains("k") | pass.contains("l") | pass.contains("m") | pass.contains("n") | pass.contains("o") | pass.contains("p") | pass.contains("q") | pass.contains("r") | pass.contains("s") | pass.contains("t") | pass.contains("u") | pass.contains("v") | pass.contains("w") | pass.contains("x") | pass.contains("y") | pass.contains("z") | pass.contains("ç"))
            return true;

        // Para ver se a senha tem numeros
        return pass.chars()
            .anyMatch(c -> c >= '0' && c <= '9');


    }

}
