package com.desktopapp;

import java.net.URL;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class LoginSceneController {
        public static Scene CreateScene() throws Exception {
        URL sceneUrl = LoginSceneController.class
            .getResource("login-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }

    @FXML
    protected TextField tfLogin;

    @FXML
    protected PasswordField pfPass;

    @FXML
    protected Button btnEnter;

    @FXML
    protected Button btnRegister;

    @FXML
    protected void Enter(ActionEvent e) throws Exception {
        Context ctx = new Context();
        var textLogin = tfLogin.getText();
        var textPass = pfPass.getText();


        // Login ficticio para testes
        if (textLogin.equals("admin") && textPass.equals("123")) {
            var crrStage = (Stage)btnEnter
                .getScene().getWindow();
            crrStage.close();

            var stage = new Stage();
            var scene = MainSceneController.CreateScene("admin");
            stage.setScene(scene);
            stage.show();
        }

        // Login real
        else if (ctx.checkUser(textLogin, textPass)) {
            var crrStage = (Stage)btnEnter
                .getScene().getWindow();
            crrStage.close();

            var stage = new Stage();
            var scene = MainSceneController.CreateScene(textLogin);
            stage.setScene(scene);
            stage.show(); 
        }

        else {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Usuário ou senha incorretos!",
                ButtonType.OK
            );

            alert.showAndWait();
            return;
        }

    }

    @FXML
    protected void Register(ActionEvent e) throws Exception {
        var crrStage = (Stage)btnRegister
            .getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = RegisterSceneController.CreateScene();
        stage.setScene(scene);
        stage.show();
    }

}
