package com.desktopapp;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class MessageSceneController implements Initializable{
    static String emailLindo;
    static String mensagemLinda;
    static String nomeLindo;

    public static Scene CreateScene(String email, String message, String name) throws Exception {
        emailLindo = email;
        mensagemLinda = message;
        nomeLindo = name;
        URL sceneUrl = MainSceneController.class
            .getResource("message-scene.fxml");
        Parent root = FXMLLoader.load(sceneUrl);
        Scene scene = new Scene(root);
        return scene;
    }

    
    @FXML
    protected Label email;
    
    @FXML
    protected Label message;

    @FXML
    protected Button btnBack;
    
    @FXML
    protected void Back(ActionEvent e) throws Exception {
        var crrStage = (Stage)btnBack
            .getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = MainSceneController.CreateScene(nomeLindo);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        email.setText(emailLindo);
        message.setText(mensagemLinda);
    }

}
