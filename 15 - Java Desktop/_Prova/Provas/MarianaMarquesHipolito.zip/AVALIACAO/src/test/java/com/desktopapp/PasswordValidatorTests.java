package com.desktopapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class PasswordValidatorTests {

    @Test
    void validateSmallPass() {
        assertEquals(ValidarRegistro.validatePassTest("oi"), false);
        assertEquals(ValidarRegistro.validatePassTest("1234"), false);
        assertEquals(ValidarRegistro.validatePassTest("oioi"), false);
        assertEquals(ValidarRegistro.validatePassTest("minh"), false);
    }

    @Test
    void validateBigPasswords() {
        assertEquals(ValidarRegistro.validatePassTest("minhasenha123"), true);
        assertEquals(ValidarRegistro.validatePassTest("1234567890123"), true);
        assertEquals(ValidarRegistro.validatePassTest("minhasenhagigantesca"), true);
        assertEquals(ValidarRegistro.validatePassTest("senhaemoji 👻"), true);
    }

    @Test
    void validateMediumPasswordsWithNums() {
        assertEquals(ValidarRegistro.validatePassTest("senha123"), false);
        assertEquals(ValidarRegistro.validatePassTest("12345"), false);
        assertEquals(ValidarRegistro.validatePassTest("123456789012"), false);
        assertEquals(ValidarRegistro.validatePassTest("oi88oi88oi88"), false);
    }

    @Test
    void validateMediumPassowrdsWithoutNums() {
        assertEquals(ValidarRegistro.validatePassTest("minhasenha"), false);
        assertEquals(ValidarRegistro.validatePassTest("mysenhaquase"), false);
    }

    @Test
    void validatePassowrdsCorrects() {
        assertEquals(ValidarRegistro.validatePassTest("minhasenha123!"), true);
        assertEquals(ValidarRegistro.validatePassTest(".012mysenhaquase"), true);
    }
}