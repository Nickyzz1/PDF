package com.desktopapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class EmailValidatorTests {

    @Test
    void validateInvalidEmails() {
        assertEquals(ValidarRegistro.validateEmailTest(""), false);
        assertEquals(ValidarRegistro.validateEmailTest("email.com"), false);
        assertEquals(ValidarRegistro.validateEmailTest("@example.com"), false);
        assertEquals(ValidarRegistro.validateEmailTest("example@.com"), false); 
        assertEquals(ValidarRegistro.validateEmailTest("example@com."), false); 
        assertEquals(ValidarRegistro.validateEmailTest("example@com"), false);
    }

    @Test
    void validateValidEmails() {
        assertEquals(ValidarRegistro.validateEmailTest("user@example.com"), true);
        assertEquals(ValidarRegistro.validateEmailTest("my.email@domain.org"), true);
        assertEquals(ValidarRegistro.validateEmailTest("name.surname@company.co"), true);
        assertEquals(ValidarRegistro.validateEmailTest("test.email+filter@domain.com"), true);
    }
}
