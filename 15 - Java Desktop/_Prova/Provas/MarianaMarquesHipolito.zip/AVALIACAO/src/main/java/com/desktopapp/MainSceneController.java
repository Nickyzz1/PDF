package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.scene.Parent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
 
public class MainSceneController {
     
    public static Scene CreateScene(User user) throws Exception
    {
        URL sceneUrl = MainSceneController.class.getResource("main-scene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        MainSceneController controller = loader.getController();
        controller.setId(user.getId());
        controller.setUser(user);
        controller.loadData();

        return scene;
    }
    
    protected long id;
    public long getId() {return id;}
    public void setId(long id) { this.id = id; }

    protected User user;

    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }

    @FXML
    protected TableView<Message> table;

    @FXML
    protected TableColumn<Message, String> nome_col;

    @FXML
    protected TableColumn<Message, String> titulo_col;

    @FXML
    protected TableColumn<Message, String> data_col;

    @FXML
    protected TableColumn<Message, Void> acao_col;

    @FXML
    protected Text ola_user;

    public void loadData() throws Exception{
        ola_user.setText("Olá, "+user.getName()+ "!");

        nome_col.setCellValueFactory(new PropertyValueFactory<>("remetente"));
        titulo_col.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        data_col.setCellValueFactory(new PropertyValueFactory<>("data"));

        acao_col.setCellFactory(param -> new TableCell<Message, Void>() {
            private final Button seeButton = new Button("Ver");
            
            {
                seeButton.setOnAction(event -> {
                    Message message = getTableView().getItems().get(getIndex());
                    var newStage = new Stage();
                    Scene newScene;
                    try {
                        var crrStage = (Stage) table.getScene().getWindow();
                        crrStage.close();
                        newScene = ReadMessageController.CreateScene(message, id);
                        System.out.println("ID NA MAIN: "+id);
                        newStage.setScene(newScene);
                        newStage.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });

                HBox hbox = new HBox(seeButton);
                hbox.setSpacing(10);
                setGraphic(hbox);
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(getGraphic());
                }
            } 
        });

        table.setItems(listaDeMensagens());
    }

    private ObservableList<Message> listaDeMensagens() {
        Context ctx = new Context();
        var query = ctx.createQuery(Message.class, "from Message m where m.idReceptor = :id");
        query.setParameter("id", id);
        var messages = query.getResultList();

        return FXCollections.observableArrayList(messages);
    }

    @FXML
    protected void escreverMensagem() throws Exception{
        var crrStage = (Stage)table.getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = WriteMessageController.CreateScene(id);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void logout() throws Exception{
        var crrStage = (Stage)table.getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = LoginSceneController.CreateScene();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void toEnviados() throws Exception{
        var crrStage = (Stage)table.getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = EnviadosController.CreateScene(id);
        stage.setScene(scene);
        stage.show();
    }
    
}