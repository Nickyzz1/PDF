package com.desktopapp;

import java.net.URL;
import java.time.LocalDate;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class WriteMessageController {
    public static Scene CreateScene(Long id) throws Exception
    {
        URL sceneUrl = WriteMessageController.class.getResource("write-message-scene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        WriteMessageController controller = loader.getController();
        controller.setId(id);

        return scene;
    }

    protected long id;
    public long getId() {return id;}
    public void setId(long id) { this.id = id; }

    @FXML
    protected TextField to;

    @FXML
    protected TextField title;

    @FXML
    protected TextArea content;

    @FXML
    protected void adicionar() throws Exception {
        Context ctx = new Context();
        Message message = new Message();

        if (to.getText().isEmpty() || title.getText().isEmpty() || content.getText().isEmpty()) {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Os campos não podem estar vazios!",
                ButtonType.OK
            );
            alert.showAndWait();
            return;
        }

        ValidarRegistro validar = new ValidarRegistro();
        if(!validar.validateEmail(to.getText())){
            Alert alert = new Alert(
                AlertType.ERROR,
                "Receptor inválido. O e-mail deve estar no formato: a@a.a",
                ButtonType.OK
            );
            alert.showAndWait();
            return;
        }

        var query = ctx.createQuery(User.class, "from User u where u.email = :e");
        query.setParameter("e", to.getText());
        var receptor = query.getResultList();

        query = ctx.createQuery(User.class, "from User u where u.id = :user");
        query.setParameter("user", this.id);
        var usuario = query.getResultList();

        message.setConteudo(content.getText());
        message.setData(LocalDate.now());
        message.setIdRemetente(this.id);
        message.setIdReceptor(receptor.get(0).getId());
        message.setTitulo(title.getText());
        message.setReceptor(receptor.get(0).getEmail());
        message.setRemetente(usuario.get(0).getEmail());

        ctx.begin();
        ctx.persist(message);
        ctx.commit();

        var crrStage = (Stage)content.getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = MainSceneController.CreateScene(usuario.get(0));
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void toMain() throws Exception {
        Context ctx = new Context();
        ctx.begin();
        var query = ctx.createQuery(User.class, "from User u where u.id = :id");
        query.setParameter("id", this.id);
        var u = query.getResultList();

        var crrStage = (Stage)content.getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = MainSceneController.CreateScene(u.get(0));
        stage.setScene(scene);
        stage.show();
    }
}
