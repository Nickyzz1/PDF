package com.desktopapp;

public class ValidarRegistro {
    public static boolean validateEmailTest(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        
        int atIndex = email.indexOf('@');
        int dotIndex = email.lastIndexOf('.');
        
        if (atIndex < 1 || dotIndex < atIndex + 2 || dotIndex >= email.length() - 1) {
            return false;
        }

        return true;
    }

    public static boolean validatePassTest(String password) {
        if (password.length() < 5)
            return false;
        
        if (password.length() > 12)
            return true;
        
        boolean containsNumber = password.chars().anyMatch(c -> c >= '0' && c <= '9');
        boolean containsLetter = password.chars().anyMatch(c -> c >= 'a' && c <= 'z');
        boolean containsCharactere = password.chars().anyMatch(c -> c == '!' || c == '?' || c == '@' || c == '.' || c == '&' || c == '#' || c == '$' || c == '%' || c == '/' || c == '_');

        if(!containsNumber || !containsLetter || !containsCharactere){
            return false;
        }
        
        return true;
    }

    public boolean validateEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        
        int atIndex = email.indexOf('@');
        int dotIndex = email.lastIndexOf('.');
        
        if (atIndex < 1 || dotIndex < atIndex + 2 || dotIndex >= email.length() - 1) {
            return false;
        }

        return true;
    }

    public boolean validatePass(String password) {
        if (password.length() < 5)
            return false;
        
        if (password.length() > 12)
            return true;
        
        boolean containsNumber = password.chars().anyMatch(c -> c >= '0' && c <= '9');
        boolean containsLetter = password.chars().anyMatch(c -> c >= 'a' && c <= 'z');
        boolean containsCharactere = password.chars().anyMatch(c -> c == '!' || c == '?' || c == '@' || c == '.' || c == '&' || c == '#' || c == '$' || c == '%' || c == '/' || c == '_');

        if(!containsNumber || !containsLetter || !containsCharactere){
            return false;
        }
        
        return true;
    }

    public boolean validateNull(String string){
        if(string == null){
            return true;
        }
        return false;
    }
}
