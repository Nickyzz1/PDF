package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ReadMessageController {
    public static Scene CreateScene(Message message, Long id) throws Exception
    {
        URL sceneUrl = MainSceneController.class.getResource("read-message-scene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        ReadMessageController controller = loader.getController();
        controller.setmessage(message);
        controller.setId(id); 
        controller.loadData();

        return scene;
    }

    protected long id;
    public long getId() {return id;}
    public void setId(long id) { this.id = id; }

    protected User user;


    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }

    @FXML
    protected Text remetente;

    @FXML
    protected Text receptor;

    @FXML
    protected Text assunto;
    
    @FXML
    protected Text conteudo;

    @FXML
    protected Text data;

    protected Message message;
    public void setmessage(Message message) { this.message = message; }

    public void loadData() {
        Context ctx = new Context();
        ctx.begin();
        var query = ctx.createQuery(this.message.getClass(), "from Message p where p.id = :id");
        query.setParameter("id", this.message.getId());
        var p = query.getResultList();

        remetente.setText(p.get(0).getRemetente());
        receptor.setText(p.get(0).getReceptor());
        assunto.setText(p.get(0).getTitulo());
        conteudo.setText(p.get(0).getConteudo());
        data.setText(String.valueOf(p.get(0).getData()));
    }

    @FXML
    protected void close() throws Exception {
        Context ctx = new Context();
        ctx.begin();
        var query = ctx.createQuery(User.class, "from User u where u.id = :id");
        query.setParameter("id", this.id);
        var u = query.getResultList();

        var crrStage = (Stage) data.getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = MainSceneController.CreateScene(u.get(0));
        stage.setScene(scene);
        stage.show();
    }
}
