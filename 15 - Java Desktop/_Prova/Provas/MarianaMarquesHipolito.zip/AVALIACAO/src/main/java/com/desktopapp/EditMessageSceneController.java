package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Message;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EditMessageSceneController {
    public static Scene CreateScene(Message message, Long id) throws Exception
    {
        URL sceneUrl = MainSceneController.class.getResource("editar-message-scene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        EditMessageSceneController controller = loader.getController();
        controller.setMessage(message);
        controller.setId(id); 
        controller.loadData();

        return scene;
    }

    protected long id;
    public long getId() {return id;}
    public void setId(long id) { this.id = id; }

    @FXML
    protected TextField receptor;

    @FXML
    protected TextField assunto;
    
    @FXML
    protected TextArea conteudo;

    protected Message message;
    public void setMessage(Message message) { this.message = message; }

    public void loadData() {
        Context ctx = new Context();
        ctx.begin();
        var query = ctx.createQuery(this.message.getClass(), "from Message m where m.id = :id");
        query.setParameter("id", this.message.getId());
        var m = query.getResultList();

        receptor.setText(m.get(0).getReceptor());
        assunto.setText(m.get(0).getTitulo());
        conteudo.setText(String.valueOf(m.get(0).getConteudo()));
    }

    @FXML
    protected void editar() throws Exception {
        
        if (receptor.getText().isEmpty() || assunto.getText().isEmpty() || conteudo.getText().isEmpty()) {
            Alert alert = new Alert(
                AlertType.ERROR,
                "Os campos não podem estar vazios!",
                ButtonType.OK
                );
                alert.showAndWait();
            return;
        }
            
        Context ctx = new Context();
        ctx.begin();

        this.message.setReceptor(receptor.getText());
        this.message.setTitulo(assunto.getText());
        this.message.setConteudo(conteudo.getText());

        ctx.update(this.message);
        
        var crrStage = (Stage) conteudo.getScene().getWindow();
        crrStage.close();       

        var stage = new Stage();
        var scene = EnviadosController.CreateScene(id);
        stage.setScene(scene);
        stage.show();
    }
}
