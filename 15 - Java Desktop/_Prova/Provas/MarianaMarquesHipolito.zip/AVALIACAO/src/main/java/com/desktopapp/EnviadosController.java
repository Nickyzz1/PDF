package com.desktopapp;

import java.net.URL;

import com.desktopapp.model.Message;
import com.desktopapp.model.User;

import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.Parent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
 
public class EnviadosController{
     
    public static Scene CreateScene(Long id) throws Exception
    {
        URL sceneUrl = EnviadosController.class.getResource("enviados-scene.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        EnviadosController controller = loader.getController();
        controller.setId(id);
        controller.loadData();

        return scene;
    }
    
    protected long id;
    public long getId() {return id;}
    public void setId(long id) { this.id = id; }

    @FXML
    protected TableView<Message> table;

    @FXML
    protected TableColumn<Message, String> para_col;

    @FXML
    protected TableColumn<Message, String> titulo_col;

    @FXML
    protected TableColumn<Message, String> data_col;

    @FXML
    protected TableColumn<Message, Void> acao_col;

    @FXML
    protected TextField tfPesquisa;

    @FXML 
    protected void pesquisar() throws Exception {
        realizarPesquisa();
    }

    @FXML 
    protected void pesquisarEnter(KeyEvent e) throws Exception {
        if (e.getCode() == KeyCode.ENTER) {
            realizarPesquisa();
        }
    }

    private void realizarPesquisa() {
        String textoPesquisa = tfPesquisa.getText().trim().toLowerCase();
        if (textoPesquisa.isEmpty()) {
            loadData();
        } else {
            Context ctx = new Context();
            var query = ctx.createQuery(Message.class, 
                "SELECT m FROM Message m WHERE LOWER(m.receptor) LIKE :searchText OR LOWER(m.conteudo) LIKE :searchText OR LOWER(m.titulo) LIKE :searchText");
            query.setParameter("searchText", "%" + textoPesquisa + "%");

            List<Message> mensagensFiltradas = query.getResultList();
            ObservableList<Message> listaFiltrada = FXCollections.observableArrayList(mensagensFiltradas);

            table.setItems(listaFiltrada);
        }
    }

    public void loadData(){
        para_col.setCellValueFactory(new PropertyValueFactory<>("receptor"));
        titulo_col.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        data_col.setCellValueFactory(new PropertyValueFactory<>("data"));

        acao_col.setCellFactory(param -> new TableCell<Message, Void>() {
            private final Button editButton = new Button("Editar");
            private final Button deleteButton = new Button("Excluir");

            {
                editButton.setOnAction(event -> {
                    Message message = getTableView().getItems().get(getIndex());

                    var newStage = new Stage();
                    Scene newScene;
                    try {
                        var crrStage = (Stage) table.getScene().getWindow();
                        crrStage.close();
                        newScene = EditMessageSceneController.CreateScene(message, id);
                        newStage.setScene(newScene);
                        newStage.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });

                deleteButton.setOnAction(event -> {
                    Alert alert = new Alert(
                        AlertType.CONFIRMATION,
                        "Você tem certeza que deseja apagar este item?",
                        ButtonType.OK,
                        ButtonType.CANCEL
                    );

                    alert.showAndWait().filter(res -> res == ButtonType.OK).ifPresent(res -> {
                        System.out.println("deletar");
                        Context ctx = new Context();
                        ctx.begin();
                        Message Message = getTableView().getItems().remove(getIndex());
                        ctx.delete(Message);
                    });
                });

                HBox hbox = new HBox(editButton, deleteButton);
                hbox.setSpacing(10);
                setGraphic(hbox);
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(getGraphic());
                }
            } 
        });

        table.setItems(listaDeMessages());
    }


    private ObservableList<Message> listaDeMessages() {
        Context ctx = new Context();
        var query = ctx.createQuery(Message.class, "from Message where idRemetente = :id");
        query.setParameter("id", this.id);
        var produtos = query.getResultList();
        
        return FXCollections.observableArrayList(produtos);
    }

    @FXML
    protected void toMain() throws Exception {
        Context ctx = new Context();
        ctx.begin();
        var query = ctx.createQuery(User.class, "from User u where u.id = :id");
        query.setParameter("id", this.id);
        var u = query.getResultList();

        var crrStage = (Stage) tfPesquisa.getScene().getWindow();
        crrStage.close();

        var stage = new Stage();
        var scene = MainSceneController.CreateScene(u.get(0));
        stage.setScene(scene);
        stage.show();
    }
}