javac -d bin "filepath"

cd Bin