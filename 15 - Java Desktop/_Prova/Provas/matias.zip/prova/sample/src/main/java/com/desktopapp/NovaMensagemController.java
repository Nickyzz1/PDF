package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.Mensagem;
import com.desktopapp.model.User;

import jakarta.persistence.TypedQuery;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class NovaMensagemController {
     public static Scene CreateScene(Integer id, User user) throws Exception
    {
        URL sceneUrl = NovaMensagemController.class.getResource("NovaMensagemScreen.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        NovaMensagemController controller = loader.getController();
        controller.setId(id);
        controller.setUser(user);
        return scene;
    }

    private Integer id;
    public void setId(Integer id){
        this.id = id;
    }

    private User user;
    public void setUser(User user){
        this.user = user;
    }

    @FXML
    protected TextField destino;

    @FXML
    protected TextField titulo;

    @FXML
    protected TextArea mensagem;

    @FXML
    protected Button enviarBtn;

    @FXML
    protected Button voltarBtn;

    public boolean validarDestino(String email){
        if (email.isEmpty())
            return false;

                Context ctx = new Context();

        TypedQuery<User> query = ctx.createQuery(User.class, "SELECT u from User u WHERE u.email = :email");
        query.setParameter("email",destino.getText());
        List<User> usersEmail = query.getResultList();

        if (usersEmail.isEmpty()) {
            return false;
        }

        return true;
    }

    @FXML
    public void enviar(){
        String email = destino.getText();

        boolean validEmail = validarDestino(email);
        if (!validEmail){
            Alert alert = new Alert (AlertType.ERROR, "Email invalido!!", ButtonType.OK);
            alert.showAndWait();
            return;
        }

        String msg = mensagem.getText();
        String tituloNovaMsg = titulo.getText();

        if (msg.length() == 0 || tituloNovaMsg.length() == 0){
            Alert alert = new Alert (AlertType.ERROR, "Digite uma mensagem e um titulo!", ButtonType.OK);
            alert.showAndWait();
            return;
        }

        Context ctxMsg = new Context();

        TypedQuery<User> query = ctxMsg.createQuery(User.class, "SELECT u from User u WHERE u.email = :email");
        query.setParameter("email",destino.getText());
        List<User> usersEmail = query.getResultList();

        User destinatario = usersEmail.get(0);
        
        Mensagem mensagemEnviada = new Mensagem();
        mensagemEnviada.setuserId(destinatario.getId());
        mensagemEnviada.setTitulo(tituloNovaMsg);
        mensagemEnviada.setTexto(msg);
        mensagemEnviada.setNomeEnvio(this.user.getName());
        
        Context ctx = new Context();

        ctx.begin();
        ctx.save(mensagemEnviada);
        ctx.commit();

        Alert alert = new Alert (AlertType.CONFIRMATION, "Mensagem enviada com sucesso!", ButtonType.OK);
        alert.showAndWait();
    }

    @FXML
    public void voltar() throws Exception{
        Stage crrStage = (Stage) voltarBtn.getScene().getWindow();
        Scene newScene = WelcomeController.CreateScene(id + 1, this.user.getId());
        crrStage.setScene(newScene);
    }
}
