package com.desktopapp;

import com.desktopapp.model.User;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application{
    public static void main(String[] args) 
    {
        User user = new User();
        user.setName("a");
        user.setPassword("asd123123");

        Context ctx = new Context();
        ctx.begin();
        ctx.save(user);
        ctx.commit();

        launch(args);
    } 
    @Override
    public void start(Stage primaryStage) throws Exception 
    {
        Scene scene = MainController.CreateScene(1);
        primaryStage.setScene(scene);
        primaryStage.show();    
    }
}

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Map;
// import java.util.stream.Collectors;
// import java.util.stream.Stream;

// public class Streams{

//     public static void main(String[] args) {
//         ArrayList<Integer> list = new ArrayList<>();

        // list.add(3);
        // list.add(3);
        // list.add(4);
        // list.add(5);
        // list.add(4);

        // boolean some = list.stream().allMatch(value -> value == 3);

        // Stream<Integer> som = list.stream().filter(value -> value == 4);

        // System.out.println(some);
        // System.out.println(som);

        // som.forEach(System.out::println);

        // Map<Boolean, List<Integer>> m =  som.collect(Collectors.groupingBy(c -> c % 2 == 0));

        // System.err.println(m);

        // System.out.println(s);
//     }
// }
