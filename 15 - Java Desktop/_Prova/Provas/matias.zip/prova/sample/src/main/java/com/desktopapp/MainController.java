package com.desktopapp;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.desktopapp.model.User;

import jakarta.persistence.TypedQuery;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class MainController {

    public static Scene CreateScene(Integer id) throws Exception
    {
        URL sceneUrl = MainController.class.getResource("MainScreen.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        
        MainController controller = loader.getController();
        controller.setId(id);
        return scene;
    }

    private Integer id;
    public void setId(Integer id){
        this.id = id;
    }

    @FXML
    protected void initialize(URL location, ResourceBundle Resources){
        this.btnLog.setText(id.toString());
    }

    @FXML
    protected Button btnLog;

    @FXML
    protected CheckBox checkBox;

    @FXML
    protected TextField loginField;

    @FXML
    protected TextField pwText;

    @FXML
    protected PasswordField pwField;

    @FXML
    protected Button registerBtn;


    @FXML
    public void sendData(ActionEvent e) throws Exception{
        Context ctx = new Context();

        TypedQuery<User> query = ctx.createQuery(User.class, "SELECT u from User u WHERE u.name = :name or u.email = :email");
        query.setParameter("name", loginField.getText());
        query.setParameter("email", loginField.getText());
        List<User> users = query.getResultList();
        
        String userPw = "";

        if (checkBox.isSelected()) {
            userPw = pwText.getText();
        }else{
            userPw = pwField.getText();
        }   

        if(users.isEmpty()){
            Alert alert = new Alert (AlertType.ERROR, "Usuario não encontrado!!", ButtonType.OK);
            alert.showAndWait();
            return;
        }else{
            User user = users.get(0);
            if (checkBox.isSelected()){
                if(!pwText.getText().equals(user.getPassword())){
                    Alert alert = new Alert(
                    AlertType.ERROR,
                    "Senha incorreta!",
                    ButtonType.OK
                );
                alert.showAndWait();
                return;
                }
    
            }else{
                if(!pwField.getText().equals(user.getPassword())){
                    Alert alert = new Alert(
                    AlertType.ERROR,
                    "Senha incorreta!",
                    ButtonType.OK
                );
                alert.showAndWait();
                return;
                }
            }

        }
        User user = users.get(0);
        System.out.println(user.getId());

        long userId = user.getId();

        Stage crrStage = (Stage) btnLog.getScene().getWindow();
        Scene newScene = WelcomeController.CreateScene(id + 1, userId);
        crrStage.setScene(newScene);
    }

    @FXML
    public void changeVisualization(MouseEvent e){
        if (checkBox.isSelected()) {
            pwText.setText(pwField.getText());
            pwText.setVisible(true);
            pwField.setVisible(false);
            return;
        }
        pwField.setText(pwText.getText());
        pwField.setVisible(true);
        pwText.setVisible(false);
    }

    @FXML
    public void registrar(MouseEvent event) throws Exception{

        Stage crrStage = (Stage) registerBtn.getScene().getWindow();
        Scene crrScene = registerBtn.getScene();
        
        Stage newStage = new Stage();
        Scene newScene = RegisterController.CreateScene(id + 1, crrScene);
        crrStage.setScene(newScene);
        // newStage.show();
    }
}
