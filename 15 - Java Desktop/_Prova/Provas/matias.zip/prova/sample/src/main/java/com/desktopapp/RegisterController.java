package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.User;
import com.junitexample.MyPasswordValidator;

import jakarta.persistence.TypedQuery;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class RegisterController {
    public static Scene CreateScene(Integer id, Scene oldScene) throws Exception
    {
        URL sceneUrl = RegisterController.class.getResource("RegisterScreen.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        RegisterController controller = loader.getController();
        controller.setId(id);
        controller.setOldScene(oldScene);
        return scene;
    }

    private Integer id;
    public void setId(Integer id){
        this.id = id;
    }

    private Scene oldScene;
    public void setOldScene(Scene oldScene){
        this.oldScene = oldScene;
    }

    @FXML
    protected TextField emailField;

    @FXML
    protected TextField userNameField;

    @FXML
    protected TextField senhaField;

    @FXML
    protected TextField confirmarSenhaField;

    @FXML
    protected Button registrarBtn;

    @FXML
    protected Button voltarBtn;

    public boolean validarSenha(String senha){

        boolean validate = MyPasswordValidator.Validate(senha);

        if (!validate)
            return validate;

        if (senha.length() < 7)
            return false;

        if (!senha.chars().anyMatch(c -> c >= '0' && c <= '9')){
            return false;
        }

        if (!senha.chars().anyMatch(c -> c < '0' || c > '9')){
            return false;
        }
        
        return true;
    }
    
    @FXML
    public void registrar(ActionEvent event) throws Exception{
        String newUserName = userNameField.getText();
        String newUserSenha = senhaField.getText();
        String newUserConfirmarSenha = confirmarSenhaField.getText();
        String newUserEmail = emailField.getText();

        if (newUserName.isEmpty() || newUserSenha.isEmpty() || newUserConfirmarSenha.isEmpty() || newUserEmail.isEmpty()){
            Alert alert = new Alert(AlertType.ERROR,"Preencha todos os campos!",
                ButtonType.OK
            );
            alert.showAndWait();
            return;
        }

        if (!newUserConfirmarSenha.equals(newUserSenha)) {
            Alert alert = new Alert(AlertType.ERROR,"Você precisa digitar a mesma senha!",
                    ButtonType.OK
                );
                alert.showAndWait();
                return;
        }

        boolean isSenhaValida = validarSenha(newUserSenha);

        if (!isSenhaValida) {
            Alert alert = new Alert(AlertType.ERROR,"Senha inválida!",
            ButtonType.OK
        );
        alert.showAndWait();
        return;
        }

        Context ctx = new Context();

        TypedQuery<User> query = ctx.createQuery(User.class, "SELECT u from User u WHERE u.name = :name");
        query.setParameter("name",newUserName);
        List<User> usersName = query.getResultList();

        if (!usersName.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR,"Usuario com esse nome já existe!",
                    ButtonType.OK
                );
                alert.showAndWait();
                return;
        }

        Context ctx2 = new Context();

        TypedQuery<User> query2 = ctx2.createQuery(User.class, "SELECT u from User u WHERE u.email = :email");
        query2.setParameter("email",newUserName);
        List<User> usersEmail = query.getResultList();

        if (!usersEmail.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR,"Usuario com esse email já existe!",
                    ButtonType.OK
                );
                alert.showAndWait();
                return;
        }


        Context ctxUser = new Context();
        
        User user = new User();
        user.setName(newUserName);
        user.setPassword(newUserSenha);
        user.setEmail(newUserEmail);


        ctxUser.begin();
        ctxUser.save(user);
        ctxUser.commit();

        Stage crrStage = (Stage) registrarBtn.getScene().getWindow();
        Scene crrScene = registrarBtn.getScene();
        
        Stage newStage = new Stage();
        Scene newScene = MainController.CreateScene(id + 1);
        crrStage.setScene(newScene);
        // newStage.show();
    }

    @FXML
    public void voltar(ActionEvent event) throws Exception{
        Stage crrStage = (Stage)registrarBtn.getScene().getWindow();
        Scene newScene = MainController.CreateScene(id + 1);
        crrStage.setScene(newScene);
    }
}
