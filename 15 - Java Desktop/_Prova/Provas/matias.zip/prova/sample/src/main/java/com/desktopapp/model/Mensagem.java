package com.desktopapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "tbProduct")

public class Mensagem {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    private Long userid;
    public Long getUserId() {
        return userid;
    }
    public void setuserId(Long userid) {
        this.userid = userid;
    }

    private String nomeEnvio;
    public String getNomeEnvio() {
        return nomeEnvio;
    }
    public void setNomeEnvio(String nomeEnvio) {
        this.nomeEnvio = nomeEnvio;
    }

    private String titulo;
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    private String texto;
    public String getTexto() {
        return texto;
    }
    public void setTexto(String texto) {
        this.texto = texto;
    }

}
    
     