package com.desktopapp;

import java.net.URL;
import java.util.List;

import com.desktopapp.model.Mensagem;
import com.desktopapp.model.User;

import jakarta.persistence.TypedQuery;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;


public class WelcomeController {
    public static Scene CreateScene(Integer id, Long userId) throws Exception
    {
        URL sceneUrl = WelcomeController.class.getResource("UserMessages.fxml");
        FXMLLoader loader = new FXMLLoader(sceneUrl);
        Parent root = loader.load();
        Scene scene = new Scene(root);

        WelcomeController controller = loader.getController();
        controller.setId(id);

        Context ctx = new Context();
        User user = ctx.find(User.class, userId);
        
        controller.setUserName(user.getName());
        controller.setUser(user);
        controller.setData();

        controller.messagesTable.setEditable(true);
        
        controller.titulo.setCellValueFactory(new PropertyValueFactory<>("Titulo"));
        controller.nomeUsuario.setCellValueFactory(new PropertyValueFactory<>("NomeEnvio"));

        return scene;
    }

    private Integer id;
    public void setId(Integer id){
        this.id = id;
    }
    private String userNameData;
    public void setUserName(String userNameData){
        this.userNameData = userNameData;
    }
    private User user;
    public void setUser(User user){
        this.user = user;
    }

    public void setData(){
        userName.setText(userNameData);
    }

    @FXML
    protected Label userName;

    
    @FXML
    protected TableColumn<Mensagem, String> titulo;
    
    @FXML
    protected TableColumn<Mensagem, String> nomeUsuario;

    @FXML
    protected Label userPw;

    @FXML
    protected PasswordField pwNewUser;

    @FXML
    protected TextField nameNewUser;

    @FXML
    protected TextField ageField;

    @FXML
    protected TextField userNameField;

    @FXML
    protected TextField pwField;

    @FXML
    protected Button createUserBtn;

    @FXML
    protected Button novaMensagemBtn;

    @FXML
    protected Button sairBtn;

    @FXML
    protected Button carregarMensagensBtn;

    @FXML
    protected TableView<Mensagem> messagesTable;
    
    
    @FXML
    public void createNewUser(ActionEvent event){

        String newUserName = userNameField.getText();

        String newUserPw = pwField.getText();

        User user = new User();
        user.setName(newUserName);
        user.setPassword(newUserPw);


        Context ctx = new Context();
        ctx.begin();
        ctx.save(user);
        ctx.commit();
    }

    @FXML
    public void novaMensagem() throws Exception{
        Stage crrStage = (Stage)novaMensagemBtn.getScene().getWindow();
        Scene newScene = NovaMensagemController.CreateScene(id + 1, this.user);
        crrStage.setScene(newScene);
    }

    @FXML
    public void carregarMensagens(){
        Context ctx = new Context();

        TypedQuery<Mensagem> query = ctx.createQuery(Mensagem.class, "SELECT m from Mensagem m WHERE m.userid = :userId");
        query.setParameter("userId", user.getId());

        List<Mensagem> mensagens = query.getResultList();

        System.out.println(mensagens.size());
        
        messagesTable.setItems(FXCollections.observableArrayList(mensagens));
    }

    @FXML
    public void sair() throws Exception{
        Stage crrStage = (Stage)novaMensagemBtn.getScene().getWindow();
        Scene newScene = MainController.CreateScene(id + 1);
        crrStage.setScene(newScene);
    }

}
